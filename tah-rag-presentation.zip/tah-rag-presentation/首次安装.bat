@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>nul
if not errorlevel 1 (
    py -3 install.py
    goto :finished
)
python -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>nul
if not errorlevel 1 (
    python install.py
    goto :finished
)
echo 未找到 Python 3.10+。请先安装 Python 3.11 或 3.12，并勾选 Add python.exe to PATH。
pause
exit /b 1

:finished
set "TAH_INSTALL_EXIT=%ERRORLEVEL%"
if not "%TAH_INSTALL_EXIT%"=="0" echo 安装失败，请保留上方错误信息。
pause
exit /b %TAH_INSTALL_EXIT%
