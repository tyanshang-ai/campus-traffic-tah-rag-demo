"""One-click local web launcher; model answers use the configured GLM endpoint."""
from pathlib import Path
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
import socket
import uuid

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "data/runtime"
RUNTIME.mkdir(parents=True, exist_ok=True)

def get_json(url):
    with urllib.request.urlopen(url, timeout=2) as response:
        return json.load(response)

def main():
    os.chdir(ROOT)
    dependencies = ["fastapi", "uvicorn", "sklearn", "pdfplumber", "docx", "multipart", "certifi"]
    if os.name == "nt":
        dependencies.append("tzdata")
    missing = [x for x in dependencies if importlib.util.find_spec(x) is None]
    if missing:
        print("缺少依赖：", ", ".join(missing))
        print("Windows：先双击‘首次安装.bat’，然后双击‘启动演示.bat’。")
        print("macOS：先双击‘首次安装.command’，然后双击‘启动演示.command’。")
        return 1
    try:
        desired_port = int(os.environ.get("TAH_PORT", "8877"))
        if not 1 <= desired_port <= 65526:
            raise ValueError
    except ValueError:
        print("TAH_PORT 必须为 1 到 65526 的整数；默认演示端口为 8877。")
        return 1
    process_file = RUNTIME / "server.json"
    if process_file.exists():
        try:
            saved = json.loads(process_file.read_text())
            status = get_json(saved["url"] + "/api/status")
            if status.get("app_id") == "tah-rag-original-project" and status.get("instance_id") == saved.get("instance_id"):
                print("系统已运行，正在打开：", saved["url"])
                if os.environ.get("TAH_NO_BROWSER") != "1": webbrowser.open(saved["url"])
                return 0
        except Exception:
            pass
    for port in range(desired_port, desired_port + 10):
        url = f"http://127.0.0.1:{port}"
        try:
            status = get_json(url + "/api/status")
            if status.get("app_id") == "tah-rag-original-project":
                print("系统已运行，正在打开：", url)
                if os.environ.get("TAH_NO_BROWSER") != "1": webbrowser.open(url)
                return 0
        except Exception:
            pass
        try:
            with socket.socket() as check:
                check.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                check.bind(("127.0.0.1", port))
            break
        except OSError:
            continue
    else:
        print("演示端口暂不可用，请设置 TAH_PORT 后重试。")
        return 1
    from app.model_provider import model_status
    provider_status = model_status()
    print("问答服务：", provider_status["provider"], provider_status["name"])
    if not provider_status["configured"]:
        print("请配置本机 .env 中的 GLM 密钥；当前可使用资料摘录与历史方案展示。")
    print("校园交通治理演示：", url)
    print("停止系统请在本窗口按 Control+C。")
    def open_when_ready():
        for _ in range(60):
            time.sleep(.5)
            try:
                get_json(url + "/api/status")
                webbrowser.open(url)
                return
            except Exception:
                pass
    if os.environ.get("TAH_NO_BROWSER") != "1":
        threading.Thread(target=open_when_ready, daemon=True).start()
    import uvicorn
    instance_id = uuid.uuid4().hex
    os.environ["TAH_INSTANCE_ID"] = instance_id
    process_file.write_text(json.dumps(dict(pid=os.getpid(), port=port, url=url, instance_id=instance_id)))
    (RUNTIME / "url.txt").write_text(url)
    try:
        uvicorn.run("app.server:app", host="127.0.0.1", port=port, log_level="warning")
    finally:
        if process_file.exists() and json.loads(process_file.read_text()).get("instance_id") == instance_id:
            process_file.unlink()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
