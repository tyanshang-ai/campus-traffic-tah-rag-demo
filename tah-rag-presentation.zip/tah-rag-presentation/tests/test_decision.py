import unittest
from pydantic import ValidationError
from app.decision import DecisionInput, SCENARIOS, decide

class DecisionTests(unittest.TestCase):
    def test_scenarios_cover_all_actions_with_valid_paths(self):
        actions = []
        for scenario in SCENARIOS:
            result = decide(DecisionInput(**scenario['input']))
            actions.append(result['action'])
            self.assertTrue(all(c['passed'] for c in result['checks']))
            chosen = next(s for s in result['scores'] if s['action'] == result['action'])
            self.assertEqual(chosen['total'], min(s['total'] for s in result['scores'] if s['admissible']))
        self.assertEqual(actions, ['release', 'throttle', 'throttle', 'warn'])

    def test_warning_threshold_and_negative_input(self):
        self.assertEqual(decide(DecisionInput(speeding=4))['action'], 'throttle')
        self.assertEqual(decide(DecisionInput(speeding=5))['action'], 'warn')
        with self.assertRaises(ValidationError):
            DecisionInput(vehicles=-1)

    def test_zero_baseline_is_finite_and_labelled(self):
        result = decide(DecisionInput(pedestrians=350, previous_pedestrians=0))
        self.assertTrue(result['trends'][0]['baseline_zero'])
        self.assertTrue(result['trends'][0]['note'])
        self.assertEqual(result['action'], 'throttle')

if __name__ == '__main__':
    unittest.main()
