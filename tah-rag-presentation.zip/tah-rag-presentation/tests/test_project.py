import hashlib
import json
import unittest
from pathlib import Path

from app.project_data import ProjectData
from scripts_import_project import EMAIL, PHONE, PLATE, SENSITIVE_KEYS, scrub

ROOT = Path(__file__).resolve().parents[1]


class OriginalProjectTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = ProjectData(ROOT / "data/project")

    def test_snapshot_counts_and_ids(self):
        data = self.project.summary()
        self.assertTrue(data["available"])
        self.assertEqual(data["counts"], {"cards": 1707, "metrics": 157, "rules": 50, "cases": 1500, "nodes": 2742, "edges": 74514, "records": 4321})
        self.assertEqual(len(self.project.card_map), 1707)
        self.assertEqual(self.project.card_map["O-metric_veh_0"]["original_id"], "metric_veh_0")
        self.assertIn("5.0", self.project.card_map["O-metric_veh_0"]["content"])

    def test_snapshot_hashes(self):
        for item in self.project.manifest["snapshot_files"]:
            blob = (ROOT / "data/project" / item["file"]).read_bytes()
            self.assertEqual(hashlib.sha256(blob).hexdigest(), item["sha256"])

    def test_source_files_have_not_changed_since_snapshot(self):
        source = Path(self.project.manifest["source_root"])
        if not source.exists():
            self.skipTest("当前电脑没有原工程；仍可使用交付快照")
        for item in self.project.manifest["sources"]:
            self.assertEqual(hashlib.sha256((source / item["file"]).read_bytes()).hexdigest(), item["sha256"])

    def test_record_actions_filters_and_details(self):
        result = self.project.list_records(action="warn", page_size=5)
        self.assertEqual(result["total"], 9)
        self.assertTrue(all(item["action"] == "warn" for item in result["items"]))
        self.assertEqual(len(result["items"]), 5)
        record = self.project.get_record(result["items"][0]["id"])
        self.assertIn("observation", record)
        self.assertEqual(record["source_ref"]["index"], record["index"])
        self.assertNotIn("graph_valid", record["validation"])
        queried = self.project.list_records(q="2025-12-01", page_size=100)
        self.assertTrue(all("2025-12-01" in row["timestamp"] for row in queried["items"]))

    def test_missing_historical_evidence_is_not_invented(self):
        self.assertEqual(sum(bool(r["evidence_ids"]) for r in self.project.records), 0)
        result = self.project.graph_for_record("R000001")
        self.assertFalse(result["found"])
        self.assertEqual(result["edges"], [])
        self.assertTrue(any(r["mentioned_card_ids"] for r in self.project.records))
        for record in self.project.records:
            if record["mentioned_card_ids"]:
                self.assertEqual(record["evidence_ids"], [])
                self.assertFalse(self.project.graph_for_record(record["id"])["found"])
                break

    def test_displayed_graph_edges_exist_in_source_snapshot(self):
        graph = self.project.graph_for_card("O-rule_hard_0", limit=30)
        self.assertTrue(graph["found"])
        self.assertLessEqual(len(graph["nodes"]), 30)
        self.assertTrue(graph["edges"])
        all_edges = {(e["source"], e["target"], e["type"]) for e in self.project.graph["edges"]}
        self.assertTrue(all((e["source"], e["target"], e["type"]) in all_edges for e in graph["edges"]))
        ids = {n["id"] for n in graph["nodes"]}
        self.assertTrue(all(e["source"] in ids and e["target"] in ids for e in graph["edges"]))

    def test_sanitizer_and_snapshot_sensitive_fields(self):
        cleaned = scrub({"phone": "13800138000", "plate_number": "京A12345", "content": "测试邮箱 user@example.com，车牌京A12345"})
        self.assertNotIn("phone", cleaned)
        self.assertNotIn("plate_number", cleaned)
        self.assertNotIn("user@example.com", cleaned["content"])
        def walk(value):
            if isinstance(value, dict):
                self.assertFalse(any(SENSITIVE_KEYS.search(key) for key in value))
                for child in value.values():
                    walk(child)
            elif isinstance(value, list):
                for child in value:
                    walk(child)
            elif isinstance(value, str):
                self.assertIsNone(PLATE.search(value))
                self.assertIsNone(PHONE.search(value))
                self.assertIsNone(EMAIL.search(value))
        walk(self.project.cards)
        walk(self.project.records)


if __name__ == "__main__":
    unittest.main()
