"""Evidence and persistence checks; no model download or inference required."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from app.engine import KnowledgeEngine, citation_ids, strip_thinking


class KnowledgeEngineTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.data = Path(self.temp.name)
        cards = [
            {"id": "P-01", "title": "校园交通治理动作", "content": "TAH-RAG 的治理动作包括正常放行、临时限流和预警。", "tags": ["校园交通", "动作", "决策"], "source": "paper.pdf", "page": 3, "provenance": "paper"},
            {"id": "P-02", "title": "论文大模型配置", "content": "论文使用 Qwen2.5-72B-Instruct，开发窗口用于选择政策参数。没有描述大模型微调训练。", "tags": ["模型", "训练", "微调", "配置"], "source": "paper.pdf", "page": 7, "provenance": "paper"},
            {"id": "D-01", "title": "演示限流阈值", "content": "每十分钟车辆超过 200 辆时，本演示规则建议限流。该阈值是演示自设参数。", "provenance": "demo", "tags": ["阈值", "限流"]},
        ]
        (self.data / "cards.json").write_text(json.dumps(cards, ensure_ascii=False))
        self.engine = KnowledgeEngine(self.data)

    def tearDown(self):
        self.temp.cleanup()

    def test_grounded_extract_retrieves_and_cites(self):
        result = self.engine.answer("校园交通有哪些治理动作", "extract")
        self.assertEqual(result["mode"], "extract")
        self.assertIn("[P-01]", result["answer"])
        self.assertEqual(result["model"], None)
        self.assertFalse(result["refused"])
        self.assertEqual(self.engine.audit()[0]["query_id"], result["query_id"])

    def test_unknown_question_refuses_without_calling_model(self):
        with patch.object(self.engine, "generate") as model:
            result = self.engine.answer("巴西总统叫什么名字", "llm")
            model.assert_not_called()
        self.assertTrue(result["refused"])
        self.assertEqual(result["mode"], "refusal")

    def test_domain_words_do_not_authorize_unknown_concrete_facts(self):
        for question in ("校园交通治理项目投资多少钱", "校园东门管理员电话号码是多少", "学校校长叫什么名字", "食堂今晚供应什么菜", "校园东门现在有多少车"):
            with self.subTest(question=question), patch.object(self.engine, "generate") as model:
                result = self.engine.answer(question, "llm")
                model.assert_not_called()
                self.assertTrue(result["refused"])

    def test_unknown_citation_is_blocked(self):
        with patch.object(self.engine, "generate", return_value="论文模型为不存在的模型 [FAKE-99]"):
            result = self.engine.answer("论文使用什么大模型配置", "llm")
        self.assertTrue(result["refused"])
        self.assertIn("已拦截", result["answer"])
        self.assertNotIn("不存在的模型", result["answer"])

    def test_missing_citation_is_blocked(self):
        with patch.object(self.engine, "generate", return_value="校园交通所有问题都已经完全解决。"):
            result = self.engine.answer("校园交通治理动作", "llm")
        self.assertTrue(result["refused"])
        self.assertIn("已拦截", result["answer"])

    def test_valid_model_answer_is_returned_with_its_actual_source(self):
        with patch.object(self.engine, "generate", return_value="包含正常放行、临时限流和预警。[P-01]"):
            result = self.engine.answer("校园交通有哪些治理动作", "llm")
        self.assertFalse(result["refused"])
        self.assertEqual([c["id"] for c in result["citations"]], ["P-01"])

    def test_uncited_refusal_cannot_smuggle_unsupported_assertions(self):
        with patch.object(self.engine, "generate", return_value="知识库未提供任何限制，所以可立即关闭所有校门。"):
            result = self.engine.answer("校园交通治理动作", "llm")
        self.assertTrue(result["refused"])
        self.assertNotIn("关闭所有校门", result["answer"])

    def test_echoed_question_is_not_a_valid_answer(self):
        question = "校园交通有哪些治理动作"
        with patch.object(self.engine, "generate", return_value=question + "？[P-01]"):
            result = self.engine.answer(question, "llm")
        self.assertTrue(result["refused"])
        self.assertIn("只复述", result["answer"])

    def test_empty_or_placeholder_answer_is_blocked(self):
        for answer in ("[P-01]", "[资料编号] 正常放行、临时限流和预警。[P-01]"):
            with self.subTest(answer=answer), patch.object(self.engine, "generate", return_value=answer):
                result = self.engine.answer("校园交通有哪些治理动作", "llm")
                self.assertTrue(result["refused"])

    def test_unreported_training_does_not_become_no_training(self):
        with self.engine.lock:
            card = self.engine.card_map["P-02"]
            card["content"] += "不能确认作者训练了模型权重。"
        with patch.object(self.engine, "generate", return_value="这篇论文没有训练或微调过模型。[P-02]"):
            result = self.engine.answer("论文训练或微调模型吗", "llm")
        self.assertTrue(result["refused"])
        self.assertIn("限定", result["warning"])

    def test_upload_persistence_duplicate_and_removal(self):
        blob = "测试项目要求：每次限流建议应包含目标地点、建议时长和可核验证据。".encode()
        item = self.engine.import_file("../项目规范.txt", blob)
        self.assertEqual(item["name"], "项目规范.txt")
        resumed = KnowledgeEngine(self.data)
        self.assertTrue(any(c["document_id"] == item["id"] for c in resumed.cards))
        with self.assertRaises(ValueError):
            resumed.import_file("重复.txt", blob)
        resumed.delete_document(item["id"])
        self.assertFalse(any(c["document_id"] == item["id"] for c in KnowledgeEngine(self.data).cards))
        with self.assertRaises(ValueError):
            resumed.delete_document("paper")

    def test_strong_uploaded_source_is_not_overridden_by_weak_builtin_tag(self):
        cards = json.loads((self.data / "cards.json").read_text())
        cards.append({"id": "P-CODE", "title": "论文代码", "content": "仅论文未提供公开仓库。", "tags": ["代码"], "provenance": "paper"})
        (self.data / "cards.json").write_text(json.dumps(cards, ensure_ascii=False))
        self.engine.reload()
        item = self.engine.import_file("保安处原项目.md", "保安处的原项目代码在哪里？本机位置为 /local/CampusTrafficRL，包含原项目代码。".encode())
        result = self.engine.answer("保安处的原项目代码在哪里？", "extract")
        self.assertFalse(result["refused"])
        self.assertIn("/local/CampusTrafficRL", result["answer"])
        self.assertEqual(result["citations"][0]["document_id"], item["id"])

    def test_thinking_is_not_presented_as_a_finished_answer(self):
        self.assertEqual(strip_thinking("<think>private</think>最终回答"), "最终回答")
        self.assertEqual(strip_thinking("<think>unfinished"), "")
        self.assertEqual(citation_ids("说明 [P-01]，证据 [P-01, D-01]"), ["P-01", "D-01"])
        self.assertEqual(citation_ids("区间 [98.74, 99.54]；证据 [P-01，FAKE-99]"), ["P-01", "FAKE-99"])


if __name__ == "__main__":
    unittest.main()
