import json
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path
from app.engine import KnowledgeEngine

class ProjectScopeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root/'project').mkdir()
        (self.root/'cards.json').write_text(json.dumps([dict(id='P001',title='论文规则',content='论文使用三类动作。',provenance='paper')]))
        cards = [dict(id='O-rule_hard_5',original_id='rule_hard_5',title='限流时长约束',content='原工程生成规则：限流最长60分钟。',provenance='original',document_id='original-rules',document_name='原工程规则卡',tags=['限流','时长'])]
        (self.root/'project/cards.json').write_text(json.dumps(cards))
        self.engine = KnowledgeEngine(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def test_project_source_names_and_scope(self):
        doc = next(d for d in self.engine.get_documents() if d['id']=='original-rules')
        self.assertEqual(doc['name'],'原工程规则卡')
        self.assertTrue(doc['protected'])
        self.assertTrue(all(c['provenance']=='original' for c in self.engine.retrieve('限流时长规则',scope='project')))
        self.assertTrue(all(c['provenance']=='paper' for c in self.engine.retrieve('论文规则',scope='paper')))

    def test_original_identifier_resolves_source(self):
        result = self.engine.answer('rule_hard_5 的最长时长是多少？','extract',scope='project')
        self.assertFalse(result['refused'])
        self.assertIn('60分钟',result['answer'])
        self.assertEqual(result['citations'][0]['original_id'],'rule_hard_5')

    def test_historical_context_is_cited_without_claiming_new_prediction(self):
        card=dict(id='H-R000001',title='历史方案',content='原记录采取临时限流，理由为车流高峰；没有保存原引用。',provenance='historical')
        result=self.engine.answer('这个历史方案的理由是什么？','extract',scope='project',context_cards=[card])
        self.assertIn('H-R000001',result['answer'])
        self.assertEqual(result['citations'][0]['provenance'],'historical')

    def test_named_gate_is_distinct_from_another_campus_gate(self):
        extra=[dict(id='O-north',original_id='north',title='北门车辆流量',content='车辆流量P95=5.0',kind='metric',provenance='original',metadata={'location':'北门','metric_type':'vehicle_count'}),dict(id='O-othernorth',original_id='othernorth',title='其他校区北门车辆流量',content='车辆流量P95=3.0',kind='metric',provenance='original',metadata={'location':'其他校区北门','metric_type':'vehicle_count'})]
        (self.root/'project/cards.json').write_text(json.dumps(extra))
        self.engine.reload()
        hits=self.engine.retrieve('北门车辆流量的P95是多少？',scope='project')
        self.assertEqual(hits[0]['id'],'O-north')

    def test_dated_case_is_not_mixed_with_other_dates(self):
        extra=[dict(id='O-case-a',original_id='case-a',title='车流高峰窗口 2025-12-13 17:40:00',content='总车流44辆',kind='case',provenance='original'),dict(id='O-case-b',original_id='case-b',title='车流高峰窗口 2025-12-14 17:40:00',content='总车流55辆',kind='case',provenance='original')]
        (self.root/'project/cards.json').write_text(json.dumps(extra))
        self.engine.reload()
        hits=self.engine.retrieve('2025年12月13日17:40的车流高峰总车流是多少？',scope='project')
        self.assertEqual([h['id'] for h in hits],['O-case-a'])

    def test_number_from_a_different_rule_is_not_returned(self):
        card=dict(id='O-west',original_id='west',title='西门限流规则',content='人流超过16且车流超过2，通行速率为70%。',kind='rule',provenance='original',metadata={'location':'西门'},tags=['限流'])
        (self.root/'project/cards.json').write_text(json.dumps([card]))
        self.engine.reload()
        with patch.object(self.engine,'generate',return_value='人流超过11且车流超过2，通行速率为70%。[O-west]'):
            result=self.engine.answer('西门限流规则是什么？',scope='project')
        self.assertTrue(result['refused'])
        self.assertIn('数值',result['warning'])

    def test_single_source_attribution_uses_only_the_provided_original_card(self):
        with patch.object(self.engine,'generate',return_value='原工程限流最长60分钟。'):
            result=self.engine.answer('rule_hard_5 的最长时长是多少？',scope='project')
        self.assertFalse(result['refused'])
        self.assertEqual([c['id'] for c in result['citations']],['O-rule_hard_5'])
        self.assertEqual(result['attribution'],'single_provided_source')

if __name__=='__main__': unittest.main()
