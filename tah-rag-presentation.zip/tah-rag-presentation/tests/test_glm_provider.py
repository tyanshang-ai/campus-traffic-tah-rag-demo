import io
import json
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from app import model_provider as provider

class GLMProviderTests(unittest.TestCase):
    def setUp(self):
        self.cfg={"provider":"glm_coding_plan","model":"glm-5.3-flash","base_url":"https://open.bigmodel.cn/api/coding/paas/v4","api_key":"test-private-value"}
        self.config=patch.object(provider,'config',return_value=self.cfg);self.config.start()
        provider._health.clear()
    def tearDown(self): self.config.stop();provider._health.clear()

    def test_uses_coding_endpoint_without_putting_key_in_body(self):
        response=io.BytesIO(json.dumps({'choices':[{'message':{'content':'回答内容'},'finish_reason':'stop'}]}).encode())
        with patch.object(provider.request,'urlopen',return_value=response) as call:
            self.assertEqual(provider.chat([{'role':'user','content':'问题'}]),'回答内容')
        sent=call.call_args.args[0]
        self.assertEqual(sent.full_url,self.cfg['base_url']+'/chat/completions')
        self.assertNotIn(self.cfg['api_key'],sent.data.decode())
        self.assertTrue(provider.model_status()['verified'])
        self.assertNotIn(self.cfg['api_key'],json.dumps(provider.model_status()))

    def test_coding_plan_never_falls_back_to_balance_endpoint(self):
        self.cfg['base_url']='https://open.bigmodel.cn/api/paas/v4'
        with patch.object(provider.request,'urlopen') as call, self.assertRaises(RuntimeError):
            provider.chat([])
        call.assert_not_called()

    def test_api_error_redacts_credentials(self):
        body=json.dumps({'error':{'code':'1004','message':'invalid '+self.cfg['api_key']}}).encode()
        error=HTTPError(self.cfg['base_url'],401,'unauthorized',{},io.BytesIO(body))
        with patch.object(provider.request,'urlopen',side_effect=error):
            with self.assertRaises(RuntimeError) as caught:provider.chat([])
        self.assertNotIn(self.cfg['api_key'],str(caught.exception))
        self.assertFalse(provider.model_status()['available'])

    def test_missing_key_and_truncated_answer_are_explicit(self):
        self.cfg['api_key']=''
        with patch.object(provider.request,'urlopen') as call, self.assertRaises(RuntimeError):provider.chat([])
        call.assert_not_called()
        self.cfg['api_key']='test-private-value'
        response=io.BytesIO(json.dumps({'choices':[{'message':{'content':'未完成'},'finish_reason':'length'}]}).encode())
        with patch.object(provider.request,'urlopen',return_value=response), self.assertRaises(RuntimeError):provider.chat([])

if __name__=='__main__':unittest.main()
