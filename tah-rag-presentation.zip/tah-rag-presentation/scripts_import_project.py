"""Create a local, traceable snapshot of the existing campus project's aggregates.

The original project is read only. This script never imports its Python code,
loads pickle/model weights, accesses raw logs, or invokes an LLM/API.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
DEFAULT_SOURCE = Path("CampusTrafficRL")
ACTION_MAP = {"正常放行": "release", "临时限流": "throttle", "发布警示": "warn", "开启绕行": "detour", "紧急关闭": "close"}
VERSION_NOTE = "本机原工程历史存档，与投稿PDF的知识库规模、样本数和模型配置未完全对齐；不是本次重跑结果。"
SENSITIVE_KEYS = re.compile(r"(?<![a-z])plate(?![a-z])|license.?plate|车牌|phone|电话|手机号|email|邮箱|api.?key|password|passwd|密钥|密码|身份证|姓名|secret|access.?token|authorization", re.I)
PLATE = re.compile(r"[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼][A-Z][A-Z0-9]{5,6}", re.I)
PHONE = re.compile(r"(?<!\d)(?:\+?86[- ]?)?1[3-9]\d{9}(?!\d)")
EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
TOKEN = re.compile(r"\b(?:sk-|Bearer\s+)[A-Za-z0-9_\-]{12,}", re.I)


def scrub(value, counts: Counter | None = None):
    counts = counts if counts is not None else Counter()
    if isinstance(value, dict):
        output = {}
        for key, item in value.items():
            if SENSITIVE_KEYS.search(str(key)):
                counts["removed_sensitive_fields"] += 1
            else:
                output[str(key)] = scrub(item, counts)
        return output
    if isinstance(value, list):
        return [scrub(item, counts) for item in value]
    if isinstance(value, str):
        for label, pattern in [("plate", PLATE), ("phone", PHONE), ("email", EMAIL), ("credential", TOKEN)]:
            value, number = pattern.subn("[已脱敏]", value)
            counts["redacted_" + label] += number
        return value
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def source_info(root: Path, relative: str):
    path = root / relative
    return {"file": relative, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size}


def normalize_cards(source: Path, redactions: Counter):
    cards, source_files = [], []
    documents = [("metrics", "metric", "原工程指标卡"), ("rules", "rule", "原工程生成规则"), ("cases", "case", "原工程历史案例")]
    for plural, kind, label in documents:
        relative = f"build/cards/{plural}.jsonl"
        source_files.append(source_info(source, relative))
        for line_no, line in enumerate((source / relative).open(encoding="utf-8"), 1):
            if not line.strip():
                continue
            raw = scrub(json.loads(line), redactions)
            original_id = str(raw["id"])
            normalized_id = "O-" + re.sub(r"[^A-Za-z0-9_.:-]", "_", original_id)
            title, content = str(raw.get("title", original_id)), str(raw.get("content", ""))
            metadata = {key: raw[key] for key in ["location", "metric_type", "thresholds", "time_range", "derived_from", "rule_type", "if_conditions", "then_action", "prohibitions", "monitoring", "applies_to", "features"] if key in raw}
            template_markers = [term for term in ("经验模式", "特定条件", "经验策略规则", "特定交通模式", "基于历史经验") if term in title + content] if kind == "rule" else []
            cards.append({
                "id": normalized_id, "original_id": original_id, "title": title, "content": content,
                "tags": list(dict.fromkeys([*raw.get("tags", []), original_id])), "kind": kind,
                "provenance": "original", "document_id": "original-" + plural,
                "document_name": label, "source": "原工程/" + relative, "page": None,
                "source_ref": {"file": relative, "original_id": original_id, "line": line_no},
                "metadata": metadata,
                "source_note": "原工程自动生成规则，含经验模板，尚未核对为正式校园规定。" if kind == "rule" else "本机原工程聚合知识卡，非新采集或新训练结果。",
                "is_generic_template": bool(template_markers), "template_markers": template_markers,
            })
    if len({c["id"] for c in cards}) != len(cards):
        raise ValueError("原卡归一化ID发生冲突")
    return cards, source_files


def normalize_graph(source: Path, cards: list[dict], redactions: Counter):
    relative = "build/graph/knowledge_graph.json"
    graph = json.loads((source / relative).read_text(encoding="utf-8"))
    card_ids = {c["original_id"]: c["id"] for c in cards}
    nodes = []
    for raw in graph.get("nodes", []):
        value = scrub(raw, redactions)
        node_id = str(value["id"])
        nodes.append({"id": node_id, "type": str(value.get("type", "Unknown")), "label": str(value.get("name", node_id)),
                      "description": str(value.get("description", "")), "location": value.get("location"), "card_id": card_ids.get(node_id)})
    node_ids = {node["id"] for node in nodes}
    edges = []
    for raw in graph.get("links", graph.get("edges", [])):
        a, b = str(raw.get("source", raw.get("from_id", ""))), str(raw.get("target", raw.get("to_id", "")))
        if a not in node_ids or b not in node_ids:
            raise ValueError("原图谱存在未定义端点")
        edge = {"source": a, "target": b, "type": str(raw.get("edge_type", raw.get("type", "RELATED_TO"))), "weight": raw.get("weight", 1)}
        edges.append(scrub(edge, redactions))
    return {"nodes": nodes, "edges": edges, "source": relative, "directed": bool(graph.get("directed", True))}, source_info(source, relative)


def normalize_records(source: Path, cards: list[dict], redactions: Counter):
    relative = "results/main/ours_trend_hybrid_rag_results.json"
    payload = json.loads((source / relative).read_text(encoding="utf-8"))
    known = {c["original_id"]: c["id"] for c in cards}
    id_pattern = re.compile(r"(?<![A-Za-z0-9_])(?:metric_[A-Za-z0-9_]+|rule_[A-Za-z0-9_]+|case_[A-Za-z0-9_]+)(?![A-Za-z0-9_])")
    records = []
    for index, raw_record in enumerate(payload.get("decisions", [])):
        raw = scrub(raw_record, redactions)
        decision = raw.get("decision", {})
        if not isinstance(decision, dict):
            decision = {}
        observation = raw.get("observation", {})
        if not isinstance(observation, dict):
            observation = {}
        rag = decision.get("rag_context", {})
        if not isinstance(rag, dict):
            rag = {}
        label = str(decision.get("action", "未记录"))
        reason = str(decision.get("reason", ""))
        duration = decision.get("duration")
        if not isinstance(duration, (int, float)):
            match = re.search(r"\d+(?:\.\d+)?", str(duration or ""))
            duration = float(match.group()) if match else None
        original_evidence_ids = [str(item) for item in rag.get("evidence_ids", [])] if isinstance(rag.get("evidence_ids", []), list) else []
        mentioned = list(dict.fromkeys(item for item in id_pattern.findall(reason) if item in known))
        records.append({
            "id": f"R{index + 1:06d}", "index": index,
            "timestamp": str(raw.get("timestamp", observation.get("timestamp", ""))),
            "location": str(decision.get("location", observation.get("gate_id", "未记录"))),
            "action": ACTION_MAP.get(label, "unknown"), "action_label": label,
            "duration_minutes": duration, "reason": reason,
            "observation": {key: observation[key] for key in ["timestamp", "gate_id", "ped_in", "ped_out", "veh_in", "veh_out", "overspeed_count", "gate_status"] if key in observation},
            "evidence_ids": original_evidence_ids,
            "evidence_card_ids": [known[item] for item in original_evidence_ids if item in known],
            "mentioned_original_ids": mentioned,
            "mentioned_card_ids": [known[item] for item in mentioned],
            "rag_context_text": str(rag.get("text", "")),
            "validation": raw.get("validation", {}), "recorded_is_valid": raw.get("is_valid"),
            "recorded_pre_validation": rag.get("pre_validation", {}),
            "source_ref": {"file": relative, "index": index, "json_pointer": f"/decisions/{index}"},
            "evidence_missing": not bool(original_evidence_ids),
        })
    period = str(payload.get("period", ""))
    period_parts = re.split(r"\s*至\s*", period)
    return records, {"start": period_parts[0] if period_parts else "", "end": period_parts[1] if len(period_parts) > 1 else "", "step_minutes": payload.get("time_step_minutes")}, source_info(source, relative)


def build_snapshot(source: Path = DEFAULT_SOURCE, output: Path = ROOT / "data/project"):
    source = Path(source).resolve()
    output = Path(output).resolve()
    if output == source or source in output.parents:
        raise ValueError("快照输出必须位于原工程外")
    redactions = Counter()
    cards, sources = normalize_cards(source, redactions)
    graph, graph_source = normalize_graph(source, cards, redactions)
    records, period, record_source = normalize_records(source, cards, redactions)
    card_counts = Counter(c["kind"] for c in cards)
    actions = Counter(r["action"] for r in records)
    labels = {r["action"]: r["action_label"] for r in records}
    manifest = {
        "snapshot_version": 1, "title": "保安处校园交通原项目成果", "source_root": str(source),
        "snapshot_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds"),
        "counts": {"cards": len(cards), "metrics": card_counts["metric"], "rules": card_counts["rule"], "cases": card_counts["case"], "nodes": len(graph["nodes"]), "edges": len(graph["edges"]), "records": len(records)},
        "card_type_counts": dict(card_counts), "node_type_counts": dict(Counter(n["type"] for n in graph["nodes"])),
        "action_counts": [{"action": action, "label": labels[action], "count": actions[action]} for action in ["release", "throttle", "warn", "detour", "close", "unknown"] if actions[action]],
        "locations": sorted({r["location"] for r in records}), "period": period,
        "version_note": VERSION_NOTE,
        "evidence_coverage": {"records_with_retrieval_ids": sum(bool(r["evidence_ids"]) for r in records), "records_with_context_text": sum(bool(r["rag_context_text"]) for r in records), "records_with_reason_mentions": sum(bool(r["mentioned_card_ids"]) for r in records)},
        "warnings": ["原工程50条规则由阈值和模板生成，含经验模式，不能直接称为正式校园规定。", "4321条历史存档没有保存本次检索证据ID；理由提及与原检索记录分开显示。", "原记录的校验标记只按原文件展示，不视为本次重新验证。", "快照仅复制知识卡、图谱及聚合历史输出；未复制原始车辆/人员日志或模型权重。"],
        "sources": [*sources, graph_source, record_source], "redactions": dict(redactions),
    }
    for name, value in [("cards.json", cards), ("graph.json", graph), ("records.json", records)]:
        write_json(output / name, value)
    manifest["snapshot_files"] = [{"file": name, "sha256": hashlib.sha256((output / name).read_bytes()).hexdigest(), "bytes": (output / name).stat().st_size} for name in ["cards.json", "graph.json", "records.json"]]
    write_json(output / "manifest.json", manifest)
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="将本机校园交通原工程的聚合成果制作成只读展示快照")
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output", type=Path, default=ROOT / "data/project")
    arguments = parser.parse_args()
    result = build_snapshot(arguments.source, arguments.output)
    print(json.dumps({"output": str(arguments.output), "counts": result["counts"], "evidence_coverage": result["evidence_coverage"], "redactions": result["redactions"]}, ensure_ascii=False, indent=2))
