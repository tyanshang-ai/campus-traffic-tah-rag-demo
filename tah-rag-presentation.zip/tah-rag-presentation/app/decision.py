"""Illustrative governance rules; no recovered campus policies or model training."""
import math
import uuid
from datetime import datetime
from zoneinfo import ZoneInfo

from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter()
LABELS = {"release": "正常放行", "throttle": "临时限流", "warn": "预警提示"}
WEIGHTS = dict(alpha=0.45, beta=0.20, gamma=0.25, eta=0.10)
RULES = [
    dict(id="D001", title="常态通行", condition="未触发下列演示风险条件", action="release"),
    dict(id="D002", title="流量升高", condition="行人流量≥600人/10分钟，或车辆流量≥220辆/10分钟", action="throttle"),
    dict(id="D003", title="流量快速上升", condition="行人流量≥350且较前窗上升≥25%，或车辆流量≥120且较前窗上升≥25%", action="throttle"),
    dict(id="D004", title="超速事件增加", condition="3≤超速事件代理次数<5次/10分钟", action="throttle"),
    dict(id="D005", title="超速风险预警", condition="超速事件代理次数≥5次/10分钟", action="warn"),
    dict(id="D006", title="人车交织高流量", condition="行人流量≥900人/10分钟且车辆流量≥300辆/10分钟", action="warn"),
]

class DecisionInput(BaseModel):
    location: str = Field(default="校园东门", min_length=1, max_length=60)
    pedestrians: int = Field(default=420, ge=0, le=100000)
    vehicles: int = Field(default=140, ge=0, le=100000)
    speeding: int = Field(default=1, ge=0, le=100000)
    previous_pedestrians: int = Field(default=400, ge=0, le=100000)
    previous_vehicles: int = Field(default=130, ge=0, le=100000)
    previous_speeding: int = Field(default=1, ge=0, le=100000)

SCENARIOS = [
    dict(id="normal", title="常态通行", description="低流量、平稳变化，观察正常放行方案。", input=dict(location="校园东门", pedestrians=260, vehicles=85, speeding=0, previous_pedestrians=250, previous_vehicles=80, previous_speeding=0)),
    dict(id="rising", title="课间流量上升", description="人流与车流同步增长，查看趋势如何触发临时限流。", input=dict(location="教学区路口", pedestrians=520, vehicles=160, speeding=1, previous_pedestrians=360, previous_vehicles=115, previous_speeding=1)),
    dict(id="congestion", title="校门通行高峰", description="绝对流量达到演示阈值，比较限流与预警成本。", input=dict(location="校园南门", pedestrians=760, vehicles=250, speeding=2, previous_pedestrians=720, previous_vehicles=240, previous_speeding=2)),
    dict(id="speeding", title="超速事件预警", description="超速代理次数达到演示阈值，硬规则限定预警动作。", input=dict(location="生活区路口", pedestrians=410, vehicles=150, speeding=7, previous_pedestrians=380, previous_vehicles=145, previous_speeding=2)),
]

def decide(state: DecisionInput):
    values = state.model_dump() if hasattr(state, "model_dump") else state.dict()
    p, v, o = state.pedestrians, state.vehicles, state.speeding
    trends = []
    for key, label in [("pedestrians", "行人流量"), ("vehicles", "车辆流量"), ("speeding", "超速事件代理")]:
        current, previous = values[key], values["previous_" + key]
        rate = (current - previous) / (abs(previous) + 1e-6)
        # Compare unrounded values. A missing baseline is shown explicitly in the UI detail.
        direction = "上升" if rate >= 0.05 else "下降" if rate <= -0.05 else "稳定"
        trends.append(dict(key=key, label=label, current=current, previous=previous,
                           rate=round(rate, 6), direction=direction,
                           baseline_zero=previous == 0, note="前窗为0，相对变化不宜直接解释为增长百分比" if previous == 0 and current else ""))
    rates = {t["key"]: t["rate"] for t in trends}
    triggered = []
    if p >= 600 or v >= 220: triggered.append(RULES[1])
    if (p >= 350 and rates["pedestrians"] >= .25) or (v >= 120 and rates["vehicles"] >= .25): triggered.append(RULES[2])
    if 3 <= o < 5: triggered.append(RULES[3])
    if o >= 5: triggered.append(RULES[4])
    if p >= 900 and v >= 300: triggered.append(RULES[5])
    if not triggered: triggered = [RULES[0]]
    risk = "高" if any(r["action"] == "warn" for r in triggered) else "中" if any(r["action"] == "throttle" for r in triggered) else "低"
    allowed = ["warn"] if risk == "高" else ["throttle", "warn"] if risk == "中" else list(LABELS)
    risk_cost = {"低": [.05, .04, .03], "中": [1., .15, .08], "高": [1., .65, .15]}[risk]
    support = {"低": [.9, .3, .1], "中": [0., 1., .1], "高": [0., .2, 1.]}[risk]
    scores = []
    for i, action in enumerate(LABELS):
        delay, intervention = [0., .45, .30][i], [0., .70, 1.][i]
        total = .45 * risk_cost[i] + .20 * delay + .25 * intervention - .10 * support[i]
        scores.append(dict(action=action, label=LABELS[action], risk_cost=risk_cost[i], delay_cost=delay,
                           intervention_cost=intervention, evidence_support=support[i],
                           total=round(total, 4), admissible=action in allowed))
    chosen = min((s for s in scores if s["admissible"]), key=lambda s: s["total"])
    action = chosen["action"]
    evidence = [dict(id=r["id"], title=r["title"], content=r["condition"], source="本系统功能演示规则",
                     page=None, provenance="demo", kind="演示规则") for r in triggered]
    # Real traversable Metric -> Rule -> Action edges for the selected action.
    supporting = [r for r in triggered if r["action"] == action]
    graph_edges = [("current-metric", "TRIGGERS", r["id"]) for r in triggered]
    graph_edges += [(r["id"], "HANDLED_BY", r["action"]) for r in triggered]
    graph_valid = any(("current-metric", "TRIGGERS", r["id"]) in graph_edges and (r["id"], "HANDLED_BY", action) in graph_edges for r in supporting)
    result = dict(
        id="D-" + uuid.uuid4().hex[:12], timestamp=datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds"),
        action=action, action_label=LABELS[action], location=state.location.strip(), duration_minutes=0 if action == "release" else 10,
        risk_level=risk, rationale=f"当前输入触发“{'、'.join(r['title'] for r in triggered)}”。在演示规则允许的动作中，{LABELS[action]}的加权成本最低（{chosen['total']:.4f}）。",
        data_origin="人工构造场景", rule_origin="功能演示规则，非校园正式规定", trends=trends,
        triggered_rules=[dict(r, action_label=LABELS[r["action"]]) for r in triggered], evidence=evidence,
        path=[dict(type="Metric", label=f"{state.location}：人流{p} / 车流{v} / 超速{o}"),
              dict(type="Trend", label=" · ".join(t["label"] + t["direction"] for t in trends)),
              dict(type="Rule", label="、".join(r["id"] + " " + r["title"] for r in supporting)),
              dict(type="Action", label=LABELS[action])],
        graph_edges=graph_edges, scores=scores, weights=WEIGHTS, input=values,
        checks=[dict(name="硬规则检查", passed=action in allowed, detail=f"允许动作：{'、'.join(LABELS[a] for a in allowed)}"),
                dict(name="规则路径检查", passed=graph_valid, detail="存在当前指标→触发规则→选定动作的实际边"),
                dict(name="引用检查", passed=bool(evidence) and all(e["id"] in {r["id"] for r in triggered} for e in evidence), detail="引用仅来自本次触发的演示规则"),
                dict(name="成本比较", passed=math.isfinite(chosen["total"]), detail="仅在规则允许的动作中比较成本")],
        disclaimer="场景、阈值和各动作成本为功能演示构造。权重形式参考论文；未复现论文实验，未连接真实门禁或交通控制设备。"
    )
    return result

@router.get("/api/scenarios")
def scenarios():
    return {"scenarios": SCENARIOS, "data_origin": "人工构造场景"}

@router.post("/api/decision")
def decision_api(state: DecisionInput):
    result = decide(state)
    # Import here to avoid a cycle when the server includes this router.
    from .server import engine
    engine.log_event(dict(type="decision", query_id=result["id"], question=f"{state.location}场景决策", answer=result["rationale"], mode="rule", action=result["action_label"], **{k: result[k] for k in ["input", "scores", "checks", "timestamp"]}))
    return result
