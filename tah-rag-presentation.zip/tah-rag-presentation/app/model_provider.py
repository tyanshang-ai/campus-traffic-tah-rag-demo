"""Server-only GLM configuration and chat client. No local model fallback."""
from __future__ import annotations

import hashlib
import json
import os
import re
import ssl
import certifi
from pathlib import Path
from urllib import request, error

ROOT = Path(__file__).resolve().parents[1]
_health: dict = {}

def config():
    values = {}
    path = ROOT / ".env"
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip().strip("\"'")
    def get(name, default=""):
        return os.environ.get(name, values.get(name, default))
    return {
        "provider": get("TAH_PROVIDER", "glm_coding_plan"),
        "model": get("TAH_MODEL", "glm-5.3-flash"),
        "base_url": get("TAH_GLM_BASE_URL", "https://open.bigmodel.cn/api/coding/paas/v4").rstrip("/"),
        "api_key": get("TAH_GLM_API_KEY"),
    }

def _fingerprint(cfg):
    return hashlib.sha256((cfg["base_url"]+cfg["model"]+cfg["api_key"]).encode()).hexdigest()

def safe_error(message, key):
    value = str(message).replace(key, "[已隐藏]") if key else str(message)
    value = re.sub(r"\b[0-9a-fA-F]{32}\.[A-Za-z0-9_-]{10,}\b|\bsk-[A-Za-z0-9_-]+", "[已隐藏]", value)
    return value[:240]

def model_status():
    cfg = config()
    configured = bool(cfg["api_key"])
    health = _health.get(_fingerprint(cfg), {})
    return {"available": configured and health.get("ok", True), "configured": configured,
            "verified": health.get("ok", False), "name": cfg["model"], "provider": "GLM Coding Plan" if cfg["provider"]=="glm_coding_plan" else "智谱 GLM API",
            "local": False, "detail": health.get("detail") or ("服务端密钥已配置，待实际请求验证" if configured else "尚未配置服务端GLM密钥")}

def chat(messages):
    cfg = config()
    if not cfg["api_key"]:
        raise RuntimeError("GLM接口未配置密钥。请在本机服务端 .env 中设置 TAH_GLM_API_KEY；可先使用资料摘录。")
    # A Coding Plan configuration never silently falls back to a paid standard endpoint.
    if cfg["provider"] == "glm_coding_plan" and cfg["base_url"] not in {
        "https://open.bigmodel.cn/api/coding/paas/v4", "https://api.z.ai/api/coding/paas/v4"}:
        raise RuntimeError("Coding Plan必须使用专用接口地址；当前未发送请求，也未改用余额接口。")
    payload={"model":cfg["model"],"messages":messages,"stream":False,"temperature":0.2,
             "max_tokens":2048,"thinking":{"type":"disabled"}}
    call=request.Request(cfg["base_url"]+"/chat/completions",data=json.dumps(payload,ensure_ascii=False).encode(),
                         headers={"Content-Type":"application/json","Authorization":"Bearer "+cfg["api_key"]})
    fp=_fingerprint(cfg)
    try:
        with request.urlopen(call,timeout=120,context=ssl.create_default_context(cafile=certifi.where())) as response:
            result=json.load(response)
        choices=result.get("choices",[])
        if not choices:
            raise RuntimeError("GLM接口未返回有效回答。")
        choice=choices[0]
        if choice.get("finish_reason")=="length":
            raise RuntimeError("GLM回答达到长度上限，未将截断文本作为完整答案展示。")
        content=choice.get("message",{}).get("content","")
        if not isinstance(content,str) or not content.strip():
            raise RuntimeError("GLM接口未返回可展示的完整回答。")
        _health[fp]={"ok":True,"detail":"实际请求已通过"}
        return content
    except error.HTTPError as exc:
        try:
            body=json.loads(exc.read().decode("utf-8",errors="replace"))
            item=body.get("error",{})
            code=str(item.get("code",exc.code))
            detail=safe_error(item.get("message","请求被服务商拒绝"),cfg["api_key"])
        except Exception:
            code,detail=str(exc.code),"服务商拒绝请求"
        message=f"GLM接口请求失败（HTTP {exc.code}，代码 {code}）：{detail}。未调用本地模型，也未切换余额接口。"
        _health[fp]={"ok":False,"detail":message}
        raise RuntimeError(message) from None
    except (OSError,ValueError) as exc:
        message="无法连接GLM接口或响应无效，请检查网络与服务端配置；可先使用资料摘录。"
        _health[fp]={"ok":False,"detail":message}
        raise RuntimeError(message) from None
