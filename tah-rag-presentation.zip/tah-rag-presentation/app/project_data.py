"""Read-only API view of a local snapshot of the original project aggregates."""
from __future__ import annotations

import copy
import json
import math
from collections import defaultdict, deque
from pathlib import Path


class ProjectData:
    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.manifest = self._load("manifest.json", {})
        self.cards = self._load("cards.json", [])
        self.records = self._load("records.json", [])
        self.graph = self._load("graph.json", {"nodes": [], "edges": []})
        self.card_map = {c["id"]: c for c in self.cards}
        self.original_card_map = {c["original_id"]: c for c in self.cards}
        self.record_map = {r["id"]: r for r in self.records}
        self.node_map = {node["id"]: node for node in self.graph.get("nodes", [])}
        self.adjacency = defaultdict(list)
        for edge in self.graph.get("edges", []):
            self.adjacency[edge["source"]].append(edge)
            self.adjacency[edge["target"]].append(edge)

    def _load(self, name, fallback):
        path = self.data_dir / name
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else fallback

    def summary(self):
        return copy.deepcopy({"available": bool(self.manifest), **self.manifest})

    def list_records(self, page=1, page_size=20, action=None, location=None, q=""):
        page, page_size = max(1, int(page)), max(1, min(100, int(page_size)))
        search = str(q or "").strip().casefold()[:200]
        selected = [r for r in self.records
                    if (not action or action == "all" or r["action"] == action or r["action_label"] == action)
                    and (not location or location == "all" or r["location"] == location)
                    and (not search or search in " ".join(str(r.get(k, "")) for k in ["timestamp", "location", "action_label", "reason"]).casefold())]
        total = len(selected)
        pages = max(1, math.ceil(total / page_size))
        page = min(page, pages)
        keys = ["id", "index", "timestamp", "location", "action", "action_label", "duration_minutes", "reason", "evidence_ids", "validation", "recorded_pre_validation", "evidence_missing", "mentioned_card_ids"]
        return {"items": [{key: copy.deepcopy(record.get(key)) for key in keys} for record in selected[(page - 1) * page_size:page * page_size]], "total": total, "page": page, "page_size": page_size, "pages": pages, "action": action, "location": location, "q": str(q or "")}

    def get_record(self, record_id):
        record = self.record_map.get(str(record_id))
        if not record:
            raise KeyError(record_id)
        result = copy.deepcopy(record)
        result["evidence"] = [copy.deepcopy(self.card_map[cid]) for cid in record["evidence_card_ids"] if cid in self.card_map]
        result["mentioned_evidence"] = [copy.deepcopy(self.card_map[cid]) for cid in record["mentioned_card_ids"] if cid in self.card_map]
        result["provenance_note"] = "本机原工程历史文件；未重新推理或重新验证。原理由中提及卡片不代表保存了该次检索结果。"
        return result

    def _graph_result(self, selected_ids, limit, note):
        selected = set(selected_ids)
        nodes = [copy.deepcopy(self.node_map[node_id]) for node_id in selected_ids if node_id in self.node_map]
        # Every displayed edge is copied from the actual source graph.
        edges = [copy.deepcopy(edge) for edge in self.graph.get("edges", []) if edge["source"] in selected and edge["target"] in selected]
        edge_limit = max(120, limit * 4)
        return {"found": bool(nodes), "nodes": nodes, "edges": edges[:edge_limit], "total_nodes": len(self.node_map), "total_edges": len(self.graph.get("edges", [])), "truncated": len(nodes) < len(self.node_map) or len(edges) > edge_limit, "source": self.graph.get("source", "build/graph/knowledge_graph.json"), "note": note}

    def _neighborhood(self, seed_ids, limit=60):
        limit = max(1, min(150, int(limit)))
        selected, visited = [], set()
        for seed in seed_ids:
            if seed in self.node_map and seed not in visited:
                selected.append(seed)
                visited.add(seed)
                if len(selected) == limit:
                    return selected
        queue = deque((seed, 0) for seed in selected)
        while queue and len(selected) < limit:
            current, depth = queue.popleft()
            if depth >= 2:
                continue
            # Prefer structural action/rule neighbors over the thousands of similar cases.
            neighbors = sorted(self.adjacency[current], key=lambda edge: (edge["type"] == "SIMILAR_TO", edge["type"]))
            for edge in neighbors:
                other = edge["target"] if edge["source"] == current else edge["source"]
                if other not in visited and other in self.node_map:
                    visited.add(other)
                    selected.append(other)
                    queue.append((other, depth + 1))
                    if len(selected) == limit:
                        break
        return selected

    def graph_overview(self, limit=60, node_type=None):
        limit = max(1, min(150, int(limit)))
        if node_type:
            seeds = [n["id"] for n in self.graph.get("nodes", []) if n["type"] == node_type][:6]
        else:
            # Two representative seeds per type, followed by real graph neighbors.
            seeds = [node["id"] for kind in ["Metric", "Rule", "Case", "Action", "RiskLevel", "Scenario"] for node in [n for n in self.graph.get("nodes", []) if n["type"] == kind][:2]]
        return self._graph_result(self._neighborhood(seeds, limit), limit, "原工程知识图谱的有界邻域，边来自已有图文件；不是某次历史决策的原检索路径。")

    def graph_for_card(self, card_id, limit=60):
        card = self.card_map.get(str(card_id)) or self.original_card_map.get(str(card_id))
        original_id = card["original_id"] if card else str(card_id)
        result = self._graph_result(self._neighborhood([original_id], limit), max(1, min(150, int(limit))), "从所选原知识卡出发读取现有图谱邻域；不表示某次历史决策实际使用过这些边。")
        result["card_id"] = card["id"] if card else None
        return result

    def graph_for_record(self, record_id, limit=60):
        record = self.get_record(record_id)
        original_ids = [self.card_map[cid]["original_id"] for cid in record["evidence_card_ids"] if cid in self.card_map]
        if not original_ids:
            return {"found": False, "record_id": record["id"], "nodes": [], "edges": [], "total_nodes": len(self.node_map), "total_edges": len(self.graph.get("edges", [])), "truncated": False, "source": record["source_ref"]["file"], "reason": "原文件未保存本次检索证据ID，不能还原该记录的证据路径。", "note": "原理由提及的知识卡可以另行查看当前图谱邻域，但不等同于原检索证据。", "suggested_card_ids": record["mentioned_card_ids"]}
        result = self._graph_result(self._neighborhood(original_ids, limit), max(1, min(150, int(limit))), "原存档中记录的证据卡在当前图谱中的关联邻域；并非已保存的完整历史路径。")
        result["record_id"] = record["id"]
        return result
