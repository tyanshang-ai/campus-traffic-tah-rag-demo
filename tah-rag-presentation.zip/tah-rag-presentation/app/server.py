"""Loopback-only FastAPI server. Start via the supplied launch script."""
from __future__ import annotations

from pathlib import Path
from typing import Literal
import os

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .engine import KnowledgeEngine, MAX_UPLOAD_BYTES, RETRIEVAL_LABEL
from .project_data import ProjectData

ROOT = Path(__file__).resolve().parents[1]
engine = KnowledgeEngine(ROOT / "data")
project = ProjectData(ROOT / "data/project")
app = FastAPI(title="TAH-RAG 校园交通治理结项系统", version="2.0.0")
from .decision import router as decision_router
app.include_router(decision_router)


class HistoryItem(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(max_length=5000)


class ChatRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)
    mode: Literal["llm", "extract"] = "llm"
    history: list[HistoryItem] = Field(default_factory=list, max_length=20)
    scope: Literal["project", "paper", "all"] = "project"
    record_id: str | None = Field(default=None, max_length=30)


@app.get("/api/status")
def status():
    documents = engine.get_documents()
    return {"app_id": "tah-rag-original-project", "version": "2.0.0", "instance_id": os.environ.get("TAH_INSTANCE_ID"), "process_pid": os.getpid(), "model": engine.model_status(), "counts": {"documents": len(documents), "cards": len(engine.cards), "project_cards": sum(c.get('provenance') == 'original' for c in engine.cards)}, "retrieval_label": RETRIEVAL_LABEL, "system_label": "保安处原项目知识问答与历史方案展示系统", "training": "复用原工程知识卡与历史记录，调用现成大模型问答", "source_pdf": (ROOT / "data/source/TAH-RAG_submission.pdf").exists()}


@app.get("/api/documents")
def documents():
    return {"documents": engine.get_documents()}


@app.get("/api/cards/{card_id}")
def card(card_id: str):
    result = history_card(card_id[2:]) if card_id.startswith("H-") else engine.get_card(card_id)
    if not result:
        raise HTTPException(404, "证据卡片不存在。")
    return result


@app.post("/api/chat")
def chat(payload: ChatRequest):
    if not payload.question.strip():
        raise HTTPException(422, "请输入问题。")
    context = [history_card(payload.record_id)] if payload.record_id and payload.scope != "paper" else None
    result = engine.answer(payload.question, payload.mode, [h.model_dump() for h in payload.history], scope=payload.scope, context_cards=context)
    result["record_id"] = payload.record_id if context else None
    return result


def load_record(record_id: str):
    try:
        record = project.get_record(record_id)
    except (KeyError, ValueError):
        raise HTTPException(404, "历史记录不存在。")
    if not record:
        raise HTTPException(404, "历史记录不存在。")
    return record


def history_card(record_id: str):
    record = load_record(record_id)
    content = (f"原项目历史记录 {record_id}，时间：{record.get('timestamp','')}；位置：{record.get('location','')}。"
               f"记录动作：{record.get('action_label','')}；持续时间：{record.get('duration_minutes','未记录')}分钟。"
               f"原记录理由：{record.get('reason','未记录')}。聚合观测：{record.get('observation',{})}。"
               f"原记录检索证据ID数量：{len(record.get('evidence_ids',[]))}。"
               f"原基础校验字段：{record.get('validation',{})}；原首轮校验存档：{record.get('recorded_pre_validation',{})}。"
               "未出现的最终图校验字段表示未记录；没有检索证据ID时不能还原原引用链。"
               "这是已保存的历史记录，不是本次预测或现场执行。原始记录的引用和图校验以实际保存字段为准，不补造缺失字段。")
    return dict(id="H-" + record_id, title=f"历史方案：{record.get('action_label','')} · {record.get('timestamp','')}",
                content=content, kind="历史方案", source="原工程历史决策存档", provenance="historical", page=None,
                record_id=record_id, source_ref=record.get("source_ref", {}), tags=["历史方案"])


@app.get("/api/project/summary")
def project_summary():
    return project.summary()


@app.get("/api/project/records")
def project_records(page: int = 1, page_size: int = 20, action: str | None = None, location: str | None = None):
    return project.list_records(page=max(1,page), page_size=max(1,min(50,page_size)), action=action, location=location)


@app.get("/api/project/records/{record_id}")
def project_record(record_id: str):
    return load_record(record_id)


@app.get("/api/project/records/{record_id}/graph")
def project_record_graph(record_id: str):
    load_record(record_id)
    return project.graph_for_record(record_id)


@app.get("/api/project/records/{record_id}/related")
def project_record_related(record_id: str):
    record = load_record(record_id)
    query = f"{record.get('action_label','')} {record.get('reason','')} {record.get('location','')}"
    cards = engine.retrieve(query[:800], k=4, scope="project")
    return {"cards": cards, "note": "本次检索参考，不是历史记录原引用"}


@app.get("/api/project/cards/{card_id}/graph")
def project_card_graph(card_id: str):
    if not engine.get_card(card_id):
        raise HTTPException(404, "知识卡片不存在。")
    return project.graph_for_card(card_id)


@app.get("/api/project/graph")
def project_graph(limit: int = 60, node_type: str | None = None):
    return project.graph_overview(limit=max(10,min(limit,100)), node_type=node_type)


@app.post("/api/documents")
async def import_document(file: UploadFile = File(...)):
    blob = await file.read(MAX_UPLOAD_BYTES + 1)
    await file.close()
    if len(blob) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "文件不得超过 20 MB。")
    try:
        return engine.import_file(file.filename or "upload.txt", blob)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.delete("/api/documents/{document_id}")
def delete_document(document_id: str):
    try:
        return engine.delete_document(document_id)
    except KeyError as exc:
        raise HTTPException(404, "资料不存在。") from exc
    except ValueError as exc:
        raise HTTPException(403, str(exc)) from exc


@app.get("/api/audit")
def audit():
    return {"items": engine.audit(100)}


@app.get("/api/audit/export")
def export_audit():
    return JSONResponse({"system": "TAH-RAG 本地演示", "note": "日志仅记录本系统演示问答和操作，不代表论文原始实验。", "items": engine.audit(10000)}, headers={"Content-Disposition": 'attachment; filename="tah-rag-audit.json"'})


@app.get("/source/paper.pdf")
def paper_pdf():
    path = ROOT / "data/source/TAH-RAG_submission.pdf"
    if not path.exists():
        raise HTTPException(404, "未找到论文源文件。")
    return FileResponse(path, media_type="application/pdf", filename="TAH-RAG_submission.pdf", content_disposition_type="inline")


@app.get("/")
def index():
    path = ROOT / "app/static/index.html"
    if not path.exists():
        return JSONResponse({"message": "界面正在准备，API 已启动。"})
    return FileResponse(path)


app.mount("/static", StaticFiles(directory=ROOT / "app/static"), name="static")
