'use strict';

const ICONS = {
  chat:'<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8v.5Z"/><path d="M8 10h8M8 14h5"/>',
  route:'<circle cx="6" cy="6" r="2"/><circle cx="18" cy="18" r="2"/><path d="M6 8v6a4 4 0 0 0 4 4h6M18 16V6H8M14 3l4 3-4 3"/>',
  library:'<path d="M4 4h4v16H4zM11 4h4v16h-4zM18 4l3 15-3 1-3-15z"/>',
  history:'<path d="M3 11a9 9 0 1 1 2.7 7M3 4v7h7M12 7v5l3 2"/>',
  shield:'<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Z"/><path d="m8.5 11.5 2.5 2.5 4.5-5"/>',
  expand:'<path d="M8 3H3v5M16 3h5v5M21 16v5h-5M3 16v5h5"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  spark:'<path d="m12 3 2.7 6.3L21 12l-6.3 2.7L12 21l-2.7-6.3L3 12l6.3-2.7L12 3ZM20 2v4M18 4h4"/>',
  graph:'<circle cx="12" cy="5" r="2"/><circle cx="5" cy="18" r="2"/><circle cx="19" cy="18" r="2"/><circle cx="12" cy="12" r="2"/><path d="M12 7v3M10.5 13.5l-4 3M13.5 13.5l4 3M7 18h10"/>',
  chart:'<path d="M4 3v17h17M8 15l4-5 4 2 5-7M17 5h4v4"/>',
  'arrow-up-right':'<path d="M6 18 18 6M6 6h12v12"/>',
  'arrow-up':'<path d="M12 19V5M5 12l7-7 7 7"/>',
  'arrow-right':'<path d="M5 12h14M12 5l7 7-7 7"/>',
  'file-search':'<path d="M14 2H5v20h14v-7M14 2v6h6l-6-6Z"/><circle cx="12" cy="14" r="3"/><path d="m14.5 16.5 3 3"/>',
  file:'<path d="M14 2H5v20h14V7l-5-5ZM14 2v6h5M8 12h8M8 16h6"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
  lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
  refresh:'<path d="M20 7v5h-5M4 17v-5h5M5.1 8a7.5 7.5 0 0 1 12.4-3L20 8M4 16l2.5 3A7.5 7.5 0 0 0 18.9 16"/>',
  flask:'<path d="M9 3h6M10 3v6L4 19a1.3 1.3 0 0 0 1.1 2h13.8a1.3 1.3 0 0 0 1.1-2L14 9V3M7 14h10"/>',
  layers:'<path d="m12 3 10 5-10 5L2 8l10-5ZM2 12l10 5 10-5M2 16l10 5 10-5"/>',
  cpu:'<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9" y="9" width="6" height="6" rx="1"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
  upload:'<path d="M12 16V3M7 8l5-5 5 5M4 16v5h16v-5"/>',
  download:'<path d="M12 3v13M7 11l5 5 5-5M4 16v5h16v-5"/>',
  close:'<path d="m6 6 12 12M6 18 18 6"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  user:'<circle cx="12" cy="8" r="3"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/>',
  copy:'<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M15 9V3H3v12h6"/>',
  trash:'<path d="M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7M14 10v7"/>'
};
const $ = id => document.getElementById(id);
const state = {view:'project', scope:'project', recordContext:null, project:null, recordPage:1, recordPages:1, selectedRecord:null, recordsVersion:0, detailVersion:0, busy:false, model:null, cards:new Map(), history:[], chatVersion:0, scenarios:[], lastDecision:null, toastTimer:null, modalFocus:null};
const initialEvidence = $('evidence-content').cloneNode(true);
function icon(name) {
  const node = document.createElement('span');
  node.className='inline-icon';
  // SVG comes only from this fixed icon dictionary; document text is never HTML.
  node.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(ICONS[name]||ICONS.file)+'</svg>';
  return node;
}
function el(tag, className='', text='') {
  const node=document.createElement(tag);
  if(className) node.className=className;
  if(text!==undefined&&text!==null) node.textContent=String(text);
  return node;
}
function renderReadableText(node,text,cards=[]) {
  // Only text nodes, emphasis and known source buttons are produced here.
  // Imported text and model responses are never interpreted as HTML.
  const value=String(text??''),known=new Map(cards.filter(card=>card&&typeof card==='object').map(card=>[card.id,card]));
  const tokens=/\*\*([^*\n]+)\*\*|\[([A-Za-z][A-Za-z0-9_.:-]{1,100})\]/g;
  node.replaceChildren();let cursor=0,match;
  while((match=tokens.exec(value))){
    if(match.index>cursor)node.append(document.createTextNode(value.slice(cursor,match.index)));
    if(match[1])node.append(el('strong','',match[1]));
    else if(known.has(match[2])){
      const card=known.get(match[2]),button=el('button','inline-citation',match[2]);button.type='button';button.title='查看来源：'+(card.title||card.id);button.setAttribute('aria-label','查看引用 '+card.id);button.addEventListener('click',()=>openCard(card));node.append(button);
    }else node.append(document.createTextNode(match[0]));
    cursor=match.index+match[0].length;
  }
  if(cursor<value.length)node.append(document.createTextNode(value.slice(cursor)));
}
function hydrateIcons(root=document) {root.querySelectorAll('[data-icon]').forEach(node=>node.replaceChildren(icon(node.dataset.icon)));}
function toast(message,error=false) {
  const node=$('toast');node.textContent=String(message);node.classList.toggle('error',error);node.classList.add('visible');
  clearTimeout(state.toastTimer);state.toastTimer=setTimeout(()=>node.classList.remove('visible'),4500);
}
async function api(path,options={}) {
  const response=await fetch(path,options);
  if(!response.ok){let detail;try{const body=await response.json();detail=body.detail||body.error||body.message;}catch(_){}throw new Error(typeof detail==='string'?detail:`请求未完成（${response.status}），请稍后重试。`);}
  return response.json();
}
function jsonOptions(body){return {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)};}
function modelProviderLabel(model=state.model){return model?.provider||(model?.local===true?'本机推理':'模型接口');}
function modelDisplayLabel(model=state.model){const name=model?.name||'大模型问答',provider=modelProviderLabel(model);return provider===name?name:`${name} · ${provider}`;}
function switchView(view) {
  const titles={project:'项目成果',chat:'知识库问答',records:'历史决策',decision:'场景推演',documents:'知识库管理',audit:'运行记录'};
  if(!titles[view]) view='project';state.view=view;
  document.querySelectorAll('.view').forEach(n=>n.classList.toggle('active',n.id==='view-'+view));
  document.querySelectorAll('.nav-item').forEach(n=>{const active=n.dataset.view===view;n.classList.toggle('active',active);if(active)n.setAttribute('aria-current','page');else n.removeAttribute('aria-current');});
  $('view-title').textContent=titles[view];history.replaceState(null,'','#'+view);
  if(view==='project'&&!state.project)loadProject();if(view==='records')loadRecords();if(view==='documents')loadDocuments();if(view==='audit')loadAudit();if(view==='decision'&&!state.scenarios.length)loadScenarios();
}
async function loadStatus() {
  try {
    const data=await api('/api/status');state.model=data.model||{};
    const available=Boolean(state.model.available),name=state.model.name||'模型接口';
    const status=$('model-state');status.replaceChildren();const dot=el('span','status-dot'+(available?'':' unavailable'));status.append(dot,el('span','',available?modelDisplayLabel():`${modelProviderLabel()} · 模型接口未就绪，可使用资料摘录`));status.title=[modelProviderLabel(),state.model.local===true?'本机推理':'网络模型接口',state.model.detail].filter(Boolean).join(' · ');
    const counts=data.counts||{};$('nav-doc-count').textContent=counts.documents??'—';$('document-count').textContent=counts.documents??'—';$('card-count').textContent=counts.cards??'—';$('model-name').textContent=available?name:`${name} · 未就绪`;$('model-name').title=[modelProviderLabel(),state.model.detail].filter(Boolean).join(' · ');
    $('kb-summary').textContent=`${counts.documents??0} 份文档 · ${counts.cards??0} 张知识卡片`;
    if(data.retrieval_label)$('kb-summary').title=data.retrieval_label;
  } catch(error) {
    state.model=null;$('model-state').replaceChildren(el('span','status-dot unavailable'),el('span','','服务未连接，请检查本地系统是否运行'));$('kb-summary').textContent='知识库暂未连接';
  }
}
function scrollChat(){const area=$('chat-scroll');requestAnimationFrame(()=>area.scrollTo({top:area.scrollHeight,behavior:'smooth'}));}
function createMessage(role,text='',meta='') {
  const wrapper=el('article','message '+role),avatar=el('div','message-avatar');avatar.append(icon(role==='user'?'user':'spark'));
  const body=el('div','message-main'),heading=el('div','message-meta',role==='user'?'你':'TAH-RAG');if(meta)heading.append(el('small','',meta));
  const content=el('div','message-content',text);body.append(heading,content);wrapper.append(avatar,body);$('messages').append(wrapper);scrollChat();return {wrapper,body,content,heading};
}
function clearChat() {
  if(state.busy){toast('当前回答完成后可以新建对话。');return;}
  state.chatVersion++;state.history=[];state.recordContext=null;renderRecordContext();$('messages').replaceChildren();$('welcome').hidden=false;$('question').value='';
  const current=$('evidence-content');const replacement=initialEvidence.cloneNode(true);current.replaceWith(replacement);hydrateIcons(replacement);$('question').focus();
}
function pageLabel(card){return card.page?`第 ${Array.isArray(card.page)?card.page.join('、'):card.page} 页`:'知识卡片';}
function sourceLink(card,label='查看原文') {
  if(!card.page||card.provenance!=='paper')return null;
  const page=Math.max(1,parseInt(Array.isArray(card.page)?card.page[0]:card.page,10)||1),link=el('a','',label);link.href='/source/paper.pdf#page='+page;link.target='_blank';link.rel='noopener';link.append(icon('arrow-up-right'));return link;
}
function cardTag(card){if(card.provenance==='original')return /rule/i.test(card.kind||card.document_id||'')?'原工程生成规则':'原项目知识';if(card.provenance==='history'||String(card.id||'').startsWith('H-R'))return '历史方案';return card.provenance==='demo'?'演示规则':card.provenance==='paper'?'论文资料':'导入文档';}
function cardSourceLabel(card){
  if(card.provenance==='paper')return pageLabel(card);
  const source=card.source_ref?.file||card.source||'知识库',name=String(source).split(/[\\/]/).pop();
  return [name,card.source_ref?.line?'第 '+card.source_ref.line+' 行':''].filter(Boolean).join(' · ');
}
function showEvidence(cards,question) {
  const panel=$('evidence-content');panel.replaceChildren();
  panel.append(el('p','reference-summary',cards.length?`本次检索到 ${cards.length} 条相关资料。点击卡片查看完整内容。`:'知识库没有找到足够相关的内容。可换一种表述，或导入相关项目文档。'));
  cards.forEach((card,index)=>{
    state.cards.set(card.id,card);const block=el('div','reference-card');block.tabIndex=0;block.setAttribute('role','button');block.setAttribute('aria-label','查看知识卡片：'+card.title);
    const head=el('div','reference-meta');head.append(el('span','reference-number',card.id||String(index+1)),el('span','source-tag'+(card.provenance==='demo'?' demo':''),cardTag(card)));
    const footer=el('div','reference-footer'),source=el('span','reference-source',cardSourceLabel(card));source.title=card.source_ref?.file||card.source||'知识库';footer.append(source,icon('arrow-up-right'));
    const excerpt=el('p');renderReadableText(excerpt,card.content||'');block.append(head,el('h3','',card.title||'相关资料'));
    if(card.original_id)block.append(el('span','reference-code','原卡编号 '+card.original_id));
    block.append(excerpt,footer);block.addEventListener('click',()=>openCard(card));block.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openCard(card);}});panel.append(block);
  });
  const note=el('div','evidence-note');note.append(icon('info'),el('p','',cards.some(c=>c.provenance==='original')?'原项目卡片保留原编号；其中规则由原工程生成，应结合现场规定核对。':cards.some(c=>c.provenance==='demo')?'标为“演示规则”的内容仅用于系统功能展示，不代表论文中的正式校园规定。':'答案与引用的对应关系可通过来源卡片继续核对。'));panel.append(note);
}
async function openCard(card) {
  if(typeof card==='string'){
    const cached=state.cards.get(card);if(cached)card=cached;else {try{card=await api('/api/cards/'+encodeURIComponent(card));}catch(error){toast(error.message,true);return;}}
  }
  state.modalFocus=document.activeElement;$('modal-label').textContent=cardTag(card)+' · '+(card.id||'');$('modal-title').textContent=card.title||'知识卡片';renderReadableText($('modal-content'),card.content||'');
  const kindLabel={metric:'指标卡',rule:'规则卡',case:'案例卡',paper:'论文资料',uploaded:'导入资料'};
  $('modal-meta').textContent=[card.source,card.page?pageLabel(card):'',card.original_id||card.source_ref?.original_id,card.source_ref?.line?'第 '+card.source_ref.line+' 行':'',kindLabel[card.kind]||card.kind].filter(Boolean).join('  ·  ');$('modal-source').replaceChildren();const link=sourceLink(card,'打开论文对应页');if(link)$('modal-source').append(link);else $('modal-source').append(el('span','reference-summary',card.provenance==='original'?'本机原项目知识卡；保留原卡编号与来源。':card.provenance==='demo'?'此卡片为人工编写的演示内容。':'来源为本机知识文档或历史记录。'));if(card.provenance==='original'&&card.source_note)$('modal-source').append(el('p','small-evidence-note',card.source_note));if(card.is_generic_template)$('modal-source').append(el('p','missing-evidence','该条为原工程的通用模板规则，具体适用条件仍需核对。'));if(card.provenance==='original'){const graphButton=el('button','secondary-button','查看原图中的关联');graphButton.prepend(icon('graph'));graphButton.addEventListener('click',()=>loadCardGraph(card.id,$('modal-source'),graphButton));$('modal-source').append(graphButton);}
  $('card-modal').hidden=false;$('close-modal').focus();
}
function closeModal(){$('card-modal').hidden=true;if(state.modalFocus&&state.modalFocus.isConnected)state.modalFocus.focus();}
async function sendQuestion(question) {
  question=question.trim();if(!question||state.busy)return;
  const mode=$('answer-mode').value;if(mode==='llm'&&state.model&&!state.model.available){toast('模型接口未就绪，可使用“资料摘录”。',true);return;}
  state.busy=true;$('send-button').disabled=true;$('new-chat').disabled=true;$('question').disabled=true;$('welcome').hidden=true;$('question').value='';
  createMessage('user',question);const responseMessage=createMessage('assistant','',mode==='extract'?'资料摘录':state.model?.name||'模型接口');
  const loading=el('div','loading-message'),dots=el('span','typing-dots');dots.append(el('span'),el('span'),el('span'));const waiting=el('span','',mode==='extract'?'正在检索知识库…':'正在检索资料并生成回答…');loading.append(dots,waiting);responseMessage.content.append(loading);
  $('send-button').replaceChildren(el('span','busy-spinner'));const started=Date.now();let ticker=setInterval(()=>{const sec=Math.floor((Date.now()-started)/1000);if(sec>3)waiting.textContent=(mode==='extract'?'正在检索知识库':modelProviderLabel()+' 正在整理答案')+` · ${sec} 秒`;},1000);
  try {
    const data=await api('/api/chat',jsonOptions({question,mode,scope:state.scope,history:state.history.slice(-6),...(state.recordContext?{record_id:state.recordContext.id}:{})}));clearInterval(ticker);
    const citations=Array.isArray(data.citations)?data.citations:[];
    renderReadableText(responseMessage.content,data.answer||'没有生成可用答案，请尝试重新提问。',citations);responseMessage.heading.replaceChildren(document.createTextNode('TAH-RAG'),el('small','',data.mode==='extract'?'资料摘录':data.mode==='refusal'?'资料不足':data.mode==='error'?'模型暂未完成':data.model||state.model?.name||'模型接口'));
    if(data.warning)responseMessage.body.append(el('div','message-warning',data.warning));if(data.mode==='error')responseMessage.wrapper.classList.add('error');
    const actions=el('div','message-actions');
    const citeButton=el('button','citation-link',citations.length?`${citations.length} 条参考资料`:'未检索到相关资料');citeButton.prepend(icon('file-search'));citeButton.addEventListener('click',()=>showEvidence(citations,question));actions.append(citeButton);
    if(data.elapsed_ms!=null)actions.append(el('span','',`${(Number(data.elapsed_ms)/1000).toFixed(1)} 秒`));
    const copy=el('button','icon-button small');copy.title='复制答案';copy.setAttribute('aria-label','复制答案');copy.append(icon('copy'));copy.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(data.answer||'');toast('答案已复制。');}catch(_){toast('当前浏览器不支持复制，请手动选择文字。');}});actions.append(copy);responseMessage.body.append(actions);
    showEvidence(citations,question);state.history.push({role:'user',content:question},{role:'assistant',content:data.answer||''});
  }catch(error){clearInterval(ticker);responseMessage.wrapper.classList.add('error');responseMessage.content.textContent=error.message+' 可检查模型接口状态，或切换为“资料摘录”后重试。';}
  finally {state.busy=false;$('send-button').disabled=false;$('new-chat').disabled=false;$('question').disabled=false;$('send-button').replaceChildren(icon('arrow-up'));scrollChat();if(state.view==='chat')$('question').focus();}
}
function documentOrigin(doc){if(doc.provenance==='original'||/^original-/.test(doc.id||''))return '原项目资料';if(doc.provenance==='demo'||doc.kind==='demo'||/demo|演示/.test(doc.id||''))return '演示规则';if(doc.protected)return '内置资料';return '导入文档';}
async function loadDocuments() {
  try {
    const data=await api('/api/documents');const docs=Array.isArray(data)?data:data.documents||[];const list=$('document-list');list.replaceChildren();
    if(!docs.length){list.append(el('div','loading-placeholder','知识库还没有文档，请导入项目资料。'));return;}
    docs.forEach(doc=>{
      const row=el('div','document-row'),symbol=el('span','document-icon');symbol.append(icon('file'));const info=el('div','document-info');info.append(el('strong','',doc.name||doc.title||doc.id));
      const meta=el('small','');meta.append(el('span','',`${doc.cards??doc.card_count??0} 张知识卡片`));if(doc.kind)meta.append(el('span','',String(doc.kind).toUpperCase()));info.append(meta);
      const origin=documentOrigin(doc);row.append(symbol,info,el('span','document-origin'+(origin==='演示规则'?' demo':''),origin));
      if(doc.protected){const protectedTag=el('span','protected-label','内置');protectedTag.prepend(icon('lock'));row.append(protectedTag);}else {
        const del=el('button','icon-button delete-button');del.title='移除文档';del.setAttribute('aria-label','移除文档 '+(doc.name||doc.id));del.append(icon('trash'));del.addEventListener('click',async()=>{
          if(!confirm(`移除“${doc.name||doc.id}”及其知识卡片？`))return;
          del.disabled=true;try{await api('/api/documents/'+encodeURIComponent(doc.id),{method:'DELETE'});toast('文档已从知识库移除。');await Promise.all([loadDocuments(),loadStatus()]);}catch(error){toast(error.message,true);del.disabled=false;}
        });row.append(del);
      }list.append(row);
    });
  }catch(error){$('document-list').replaceChildren(el('div','inline-error',error.message));}
}
async function uploadDocument(file) {
  if(!file)return;const suffix=(file.name.split('.').pop()||'').toLowerCase();if(!['pdf','txt','md','docx'].includes(suffix)){toast('请选择 PDF、TXT、Markdown 或 DOCX 文档。',true);return;}
  if(file.size>20*1024*1024){toast('单份文档请控制在 20 MB 以内。',true);return;}
  const zone=$('upload-zone');if(zone.classList.contains('busy'))return;zone.classList.add('busy');$('upload-title').textContent='正在导入 '+file.name+'…';$('upload-description').textContent='提取文本并建立知识卡片，请稍候。';
  try {const body=new FormData();body.append('file',file);const data=await api('/api/documents',{method:'POST',body});toast(data.message||`“${file.name}”已加入知识库。`);await Promise.all([loadDocuments(),loadStatus()]);}
  catch(error){toast(error.message,true);}finally{zone.classList.remove('busy');$('upload-title').textContent='点击选择，或将文档拖到这里';$('upload-description').textContent='支持 PDF、TXT、Markdown、DOCX · 文档保存在本机';$('document-upload').value='';}
}
async function loadScenarios() {
  try {const data=await api('/api/scenarios');state.scenarios=data.scenarios||[];const list=$('scenarios');list.replaceChildren();
    state.scenarios.forEach((scenario,index)=>{const card=el('button','scenario-card');card.dataset.id=scenario.id;card.type='button';card.append(el('span','scenario-number','SCENARIO '+String(index+1).padStart(2,'0')),el('strong','',scenario.title),el('p','',scenario.description));const arrow=el('span','scenario-arrow');arrow.append(icon('arrow-up-right'));card.append(arrow);card.addEventListener('click',()=>{
      for(const [key,value]of Object.entries(scenario.input||{})){const field=$(key);if(field&&['INPUT','SELECT'].includes(field.tagName))field.value=value;}
      list.querySelectorAll('.scenario-card').forEach(n=>n.classList.toggle('selected',n===card));toast('已填入演示场景，点击“生成治理建议”查看结果。');
    });list.append(card);});if(!state.scenarios.length)list.append(el('div','loading-placeholder','暂无预设场景，可直接填写下方观测值。'));
  }catch(error){$('scenarios').replaceChildren(el('div','inline-error',error.message));}
}
function subtitle(text,name){const node=el('h3','decision-subtitle',text);if(name)node.prepend(icon(name));return node;}
function renderDecision(data) {
  state.lastDecision=data;const panel=$('decision-result');panel.replaceChildren();const top=el('div','decision-result-header');top.append(el('h2','','治理建议'),el('span','demo-source',data.data_origin||'人工构造场景'));panel.append(top);
  const result=el('div','action-result '+(data.action||'')),summary=el('div');summary.append(el('div','action-result-label','建议动作'),el('strong','',data.action_label||data.action));
  const details=el('div','action-result-details');details.append(el('div','',data.location||''),el('div','',`风险等级：${data.risk_level||'—'}`),el('div','',data.duration_minutes?`建议持续 ${data.duration_minutes} 分钟`:'保持常态观察'));result.append(summary,details);panel.append(result,el('p','decision-rationale',data.rationale||''));
  const trends=el('div','trend-row');(data.trends||[]).forEach(item=>{const card=el('div','trend-card'),values=el('div','trend-values');values.append(el('small','',String(item.previous)+' →'),document.createTextNode(String(item.current)));
    const chart=el('div','trend-chart'),max=Math.max(Number(item.previous),Number(item.current),1),prev=el('span','trend-bar'),curr=el('span','trend-bar current');prev.style.height=Math.max(5,Number(item.previous)/max*100)+'%';curr.style.height=Math.max(5,Number(item.current)/max*100)+'%';chart.append(prev,curr);
    const rate=Number(item.rate);const rateText=item.baseline_zero?(Number(item.current)===0?'无变化':'无可比基线'):(Number.isFinite(rate)?`${rate>=0?'+':''}${(rate*100).toFixed(1)}%`:'');card.append(el('div','trend-card-label',item.label),values,chart,el('div','trend-direction',[item.direction,rateText].filter(Boolean).join(' · ')));trends.append(card);});panel.append(trends);
  panel.append(subtitle('状态与行动的证据路径','graph'));const graph=el('div','graph-path');(data.path||[]).forEach((item,index)=>{if(index)graph.append(el('span','path-arrow','→'));const node=el('div','path-node '+String(item.type||'').toLowerCase());node.append(el('small','',String(item.type||'').toUpperCase()),document.createTextNode(item.label||''));graph.append(node);});panel.append(graph);
  if((data.triggered_rules||[]).length){panel.append(subtitle('本次命中的演示规则','shield'));const rules=el('div','rule-list');data.triggered_rules.forEach(rule=>{const item=el('div','rule-item');item.append(el('strong','',`${rule.id} · ${rule.title}`),el('p','',rule.condition));rules.append(item);});panel.append(rules);}
  if((data.scores||[]).length){panel.append(subtitle('候选动作成本比较 · 越低越优','chart'));const scores=data.scores||[],max=Math.max(...scores.filter(s=>Number.isFinite(Number(s.total))).map(s=>Math.abs(Number(s.total))),1);scores.forEach(score=>{const admissible=score.admissible!==false,row=el('div','score-row'+(score.action===data.action?' selected':''));row.append(el('span','',score.label||score.action));const track=el('div','score-track'),fill=el('div','score-fill');fill.style.width=(admissible?Math.max(2,Math.abs(Number(score.total)||0)/max*100):0)+'%';track.append(fill);row.append(track,el('span','score-value',admissible?Number(score.total).toFixed(3):'受约束'));row.title=admissible?`风险 ${score.risk_cost} · 延迟 ${score.delay_cost} · 干预 ${score.intervention_cost} · 证据 ${score.evidence_support}`:'未通过硬规则，不参与成本排序';panel.append(row);});}
  const checks=el('div','checks');(data.checks||[]).forEach(check=>{const tag=el('span','check-tag'+(check.passed?'':' failed'),check.name||'校验');tag.prepend(icon(check.passed?'check':'info'));tag.title=check.detail||'';checks.append(tag);});panel.append(checks);
  if((data.evidence||[]).length){const refs=el('div','decision-evidence');data.evidence.forEach(card=>{state.cards.set(card.id,card);const button=el('button','citation-link',card.id+' · 演示依据');button.prepend(icon('file'));button.addEventListener('click',()=>openCard(card));refs.append(button);});panel.append(refs);}
  panel.append(el('p','decision-disclaimer',data.disclaimer||data.rule_origin||'功能演示规则，非校园正式规定。'));
  const follow=el('button','secondary-button','了解论文如何校验决策');follow.prepend(icon('chat'));follow.addEventListener('click',()=>{if(state.busy){toast('请等待当前回答完成。');return;}clearChat();setScope('paper');switchView('chat');$('question').value='论文中的规则引擎、策略成本评分和图路径校验是如何配合的？';$('question').focus();});panel.append(follow);
}
async function runDecision(event) {
  event.preventDefault();const input={};for(const key of ['location','pedestrians','vehicles','speeding','previous_pedestrians','previous_vehicles','previous_speeding'])input[key]=key==='location'?$(key).value.trim():Number($(key).value);
  if(!input.location){toast('请填写观测位置。',true);return;}
  const button=$('decision-button');button.disabled=true;button.replaceChildren(el('span','busy-spinner'),document.createTextNode('正在计算方案…'));
  try{const data=await api('/api/decision',jsonOptions(input));renderDecision(data);if(window.innerWidth<850)$('decision-result').scrollIntoView({behavior:'smooth',block:'start'});}
  catch(error){toast(error.message,true);}
  finally{button.disabled=false;button.replaceChildren(icon('spark'),document.createTextNode('生成治理建议'),icon('arrow-right'));}
}
function formatTime(value){if(!value)return '';const date=new Date(value);if(Number.isNaN(date.getTime()))return String(value);return new Intl.DateTimeFormat('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false,timeZone:'Asia/Shanghai'}).format(date);}
async function loadAudit() {
  try{const data=await api('/api/audit');const items=Array.isArray(data)?data:data.items||[],list=$('audit-list');list.replaceChildren();if(!items.length){list.append(el('div','loading-placeholder','还没有运行记录。完成一次问答或决策演示后，即可在此查看。'));return;}
    items.slice().sort((a,b)=>String(b.timestamp||b.created_at||b.time||'').localeCompare(String(a.timestamp||a.created_at||a.time||''))).forEach(item=>{const kind=item.type||item.event||item.action||'chat',isDecision=/decision|决策/.test(kind),isChat=/chat|问答/.test(kind);const row=el('article','audit-item'),mark=el('span','audit-icon');mark.append(icon(isDecision?'route':isChat?'chat':'file'));
      const eventLabel=kind==='document_import'?'导入资料':kind==='document_delete'?'移除资料':null;const body=el('div','audit-main');body.append(el('strong','',eventLabel?[eventLabel,item.name||item.filename].filter(Boolean).join(' · '):(item.question||item.query||item.title||item.filename||(isDecision?`${item.location||'交通状态'} · ${item.action_label||'治理方案'}`:kind))));
      if(item.answer||item.rationale||item.detail){const text=item.answer||item.rationale||item.detail;body.append(el('p','',typeof text==='string'?(text.length>210?text.slice(0,210)+'…':text):JSON.stringify(text)));}
      const meta=el('div','audit-meta');meta.append(el('span','',isDecision?'规则与成本决策':isChat?(item.mode==='extract'?'资料摘录':item.mode==='refusal'?'资料不足':item.mode==='error'?'模型暂未完成':'知识库问答'):'知识库操作'));
      if(item.model)meta.append(el('span','',typeof item.model==='string'?item.model:item.model.name||''));if(item.elapsed_ms!=null)meta.append(el('span','',`${(Number(item.elapsed_ms)/1000).toFixed(1)} 秒`));
      const ids=item.citation_ids||item.citations||item.evidence_ids;if(Array.isArray(ids)&&ids.length)meta.append(el('span','',`${ids.length} 条依据`));if(item.query_id||item.id)meta.append(el('span','',String(item.query_id||item.id)));
      body.append(meta);row.append(mark,body,el('time','audit-time',formatTime(item.timestamp||item.created_at||item.time)));list.append(row);
    });
  }catch(error){$('audit-list').replaceChildren(el('div','inline-error',error.message));}
}

const PROJECT_PROMPTS = [
  ['查看管控规则','北门原工程限流规则是什么？','shield','blue'],
  ['查询历史案例','2025-10-14 13:15的人流高峰案例记录了多少人？','history','purple'],
  ['查询流量指标','北门车辆流量P95是多少？','chart','teal'],
  ['查看另一点位','西门原工程限流规则是什么？','route','amber']
];
const PAPER_PROMPTS = [
  ['了解决策流程','TAH-RAG 包含哪些阶段？','route','blue'],
  ['查看知识图谱','论文知识图谱包含哪些节点？','graph','purple'],
  ['查看治理动作','论文有哪三类治理动作？','shield','teal'],
  ['了解研究边界','历史回放研究有哪些局限？','chart','amber']
];
const NODE_TYPES = {Metric:'指标',Rule:'规则',Case:'案例',Action:'行动',RiskLevel:'风险等级',Scenario:'场景',Trend:'趋势'};
const NODE_COLORS = {Metric:'#3b6fe8',Rule:'#159a8b',Case:'#8b6fd2',Action:'#d29b39',RiskLevel:'#d56b70',Scenario:'#718299',Trend:'#0e9eab'};
const LOCATION_LABELS = {all:'全校汇总',gate_default:'默认点位',gate_north:'北门',gate_south:'南门',gate_east:'东门',gate_west:'西门',gate_other:'其他点位'};
function locationLabel(value,fallback='未记录位置'){return value==null||value===''?fallback:LOCATION_LABELS[String(value)]||String(value);}
function locationNode(tag,className,value,fallback='未记录位置'){const node=el(tag,className,locationLabel(value,fallback));if(value!=null)node.title=String(value);return node;}
function numberText(value){const number=Number(value);return value==null||!Number.isFinite(number)?'—':number.toLocaleString('zh-CN');}
function compactText(value,max=90){const text=typeof value==='string'?value:value==null?'':JSON.stringify(value);return text.length>max?text.slice(0,max)+'…':text;}
function setScope(scope){
  if(state.scope!==scope&&state.recordContext){state.recordContext=null;renderRecordContext();}
  state.scope=['project','paper','all'].includes(scope)?scope:'project';$('answer-scope').value=state.scope;
  $('scope-description').textContent=state.scope==='project'?'指标 · 生成规则 · 历史案例':state.scope==='paper'?'论文方法 · 实验与边界':'原项目 · 论文 · 导入资料';
  const grid=$('prompt-grid');grid.replaceChildren();
  (state.scope==='paper'?PAPER_PROMPTS:PROJECT_PROMPTS).forEach(([title,question,name,color])=>{
    const button=el('button','prompt-card');button.dataset.prompt=question;const symbol=el('span','prompt-icon '+color);symbol.append(icon(name));const arrow=el('i');arrow.append(icon('arrow-up-right'));button.append(symbol,el('strong','',title),el('span','',question),arrow);button.addEventListener('click',()=>sendQuestion(question));grid.append(button);
  });
}
function renderRecordContext(){
  const panel=$('record-context');panel.replaceChildren();panel.hidden=!state.recordContext;
  if(!state.recordContext)return;
  const text=el('div');text.append(el('strong','','正在讨论历史方案 '+state.recordContext.id),el('span','',[state.recordContext.timestamp||'',locationLabel(state.recordContext.location),state.recordContext.action_label||''].filter(Boolean).join(' · ')));
  const clear=el('button','icon-button small');clear.setAttribute('aria-label','清除历史方案上下文');clear.append(icon('close'));clear.addEventListener('click',()=>{if(state.busy){toast('当前回答完成后可以清除方案上下文。');return;}state.recordContext=null;renderRecordContext();});panel.append(icon('history'),text,clear);
}
function askAboutRecord(record){
  if(state.busy){toast('请等待当前回答完成后再选择历史方案。');return;}
  clearChat();setScope('project');state.recordContext={id:record.id,timestamp:record.timestamp,action_label:record.action_label,location:record.location};renderRecordContext();switchView('chat');
  $('question').value='这条历史方案记录了什么动作，理由是什么？';$('question').focus();
}
async function loadProject(){
  try{
    const data=await api('/api/project/summary');state.project=data;renderProjectSummary(data);populateRecordFilters(data);
  }catch(error){$('project-stats').replaceChildren(el('div','inline-error',error.message));$('project-breakdown').replaceChildren(el('p','muted-copy','原项目资料暂时无法读取。'));$('project-source').replaceChildren(el('p','muted-copy','请确认本地项目快照已准备。'));}
  await loadProjectGraph();
}
function renderProjectSummary(data){
  const counts=data.counts||{},stats=$('project-stats');stats.replaceChildren();
  [['cards','知识卡片','指标、规则与案例，均保留来源','library'],['nodes','图谱节点','连接指标、规则、行动与场景','graph'],['edges','图谱关系','来自原工程的实际关联','layers'],['records','历史决策','可筛选、查看并追问的已存方案','history']].forEach(([key,label,note,name])=>{
    const block=el('div','project-stat surface stat-'+key),symbol=el('span','stat-icon');symbol.append(icon(name));const body=el('div');body.append(el('small','',label),el('strong','',numberText(counts[key])),el('span','',note));block.append(symbol,body);stats.append(block);
  });
  const content=$('project-breakdown');content.replaceChildren();const cards=el('div','knowledge-composition');
  const cardTotal=Number(counts.cards)||0;
  [['metrics','指标卡','metric'],['rules','生成规则卡','rule'],['cases','历史案例卡','case']].forEach(([key,label,cls])=>{
    const count=Number(counts[key])||0,block=el('div','composition-item '+cls);
    block.append(el('strong','',numberText(counts[key])),el('span','',label),el('small','',cardTotal?`占知识库 ${(count/cardTotal*100).toFixed(1)}%`:'占比暂不可用'));cards.append(block);
  });content.append(cards,el('h3','small-section-heading','历史动作分布'));
  const actions=data.action_counts||[],recordTotal=Number(counts.records)||actions.reduce((total,item)=>total+(Number(item.count)||0),0);
  actions.forEach(item=>{
    const count=Number(item.count)||0,ratio=recordTotal?count/recordTotal*100:0,row=el('div','distribution-row '+String(item.action||'')),track=el('span','distribution-track'),fill=el('span','distribution-fill');
    fill.style.width=ratio+'%';track.append(fill);track.setAttribute('aria-hidden','true');const value=el('div','distribution-value');value.append(el('strong','',numberText(item.count)),el('span','distribution-percentage',ratio>0&&ratio<.1?'<0.1%':ratio.toFixed(1)+'%'));
    row.append(el('span','',item.label||item.action),track,value);row.setAttribute('aria-label',`${item.label||item.action}，${numberText(item.count)} 条，占历史记录 ${ratio.toFixed(2)}%`);content.append(row);
  });
  const source=$('project-source');source.replaceChildren();source.append(el('span','archive-label','本机原工程 · 历史存档'),el('p','source-project-title',data.title||'校园交通知识增强决策项目'));
  if(data.period){const period=data.period;source.append(el('p','source-meta-line','记录时间 '+(typeof period==='string'?period:[period.start,period.end].filter(Boolean).join(' — '))));}
  source.append(el('p','version-note','原工程成果快照，与投稿稿件版本分别标注。'));
  const details=el('details','source-summary-details'),toggle=el('summary','','查看来源与版本说明');toggle.append(icon('arrow-right'));const detailContent=el('div','source-details-content');
  detailContent.append(el('p','source-path',data.source_root||'本机原项目快照'),el('p','source-fine-print',data.version_note||'本地历史项目资料；与投稿最终版本分别标注。'));
  const warnings=Array.isArray(data.warnings)?data.warnings:[];
  if(warnings.length){const list=el('ul','source-warning-list');warnings.forEach(warning=>list.append(el('li','',warning)));detailContent.append(list);}
  if(data.snapshot_at)detailContent.append(el('p','source-meta-line','资料快照 '+String(data.snapshot_at).slice(0,19).replace('T',' ')));
  details.append(toggle,detailContent);source.append(details);
}
function populateRecordFilters(data){
  const action=$('record-action'),location=$('record-location'),actionValue=action.value,locationValue=location.value;
  action.replaceChildren(el('option','','全部动作'));action.firstElementChild.value='';(data.action_counts||[]).forEach(item=>{const option=el('option','',(item.label||item.action)+' · '+numberText(item.count));option.value=item.action;action.append(option);});action.value=actionValue;
  location.replaceChildren(el('option','','全部位置'));location.firstElementChild.value='';(data.locations||[]).forEach(value=>{const option=el('option','',locationLabel(value));option.value=value;option.title=String(value);location.append(option);});location.value=locationValue;
}
function svgElement(name,attrs={}){const element=document.createElementNS('http://www.w3.org/2000/svg',name);Object.entries(attrs).forEach(([key,value])=>element.setAttribute(key,String(value)));return element;}
function renderGraph(host,data,focusId=null){
  host.replaceChildren();const nodes=Array.isArray(data.nodes)?data.nodes:[],edges=Array.isArray(data.edges)?data.edges:[];
  if(data.found===false||!nodes.length){host.append(el('div','graph-empty',data.reason||data.note||'本次没有可展示的图谱关联。'));return {nodes:0,edges:0};}
  const svg=svgElement('svg',{viewBox:'0 0 960 420',role:'group','aria-label':'原项目知识图谱的实际节点与关系，可选择节点查看详情'}),defs=svgElement('defs'),marker=svgElement('marker',{id:'graph-arrow-'+Math.random().toString(36).slice(2),viewBox:'0 0 10 10',refX:21,refY:5,markerWidth:4,markerHeight:4,orient:'auto-start-reverse'});marker.append(svgElement('path',{d:'M 0 0 L 10 5 L 0 10 z',fill:'#94a6be'}));defs.append(marker);svg.append(defs);
  const types=Array.from(new Set(nodes.map(node=>node.type||'Entity'))),preferred=['Metric','Rule','Case','Action','RiskLevel','Scenario','Trend'];types.sort((a,b)=>(preferred.indexOf(a)<0?99:preferred.indexOf(a))-(preferred.indexOf(b)<0?99:preferred.indexOf(b)));
  const positions=new Map(),groups=new Map(types.map(type=>[type,nodes.filter(node=>(node.type||'Entity')===type)]));
  const laneWidth=900/types.length;
  types.forEach((type,typeIndex)=>{
    const group=groups.get(type),left=30+typeIndex*laneWidth,x=left+laneWidth/2,color=NODE_COLORS[type]||'#718299';
    svg.append(svgElement('rect',{x:left+5,y:12,width:laneWidth-10,height:368,rx:16,fill:color,'fill-opacity':.055}));
    const label=svgElement('text',{x,y:39,'text-anchor':'middle',fill:color,'font-size':14,'font-weight':600,class:'graph-lane-title'});label.textContent=NODE_TYPES[type]||type;
    const count=svgElement('text',{x,y:58,'text-anchor':'middle',fill:'#728298','font-size':11,class:'graph-lane-count'});count.textContent=group.length+' 个节点';svg.append(label,count);
    group.forEach((node,index)=>{
      const columns=group.length>18?3:group.length>8?2:1,rowCount=Math.ceil(group.length/columns),column=index%columns,row=Math.floor(index/columns),spacing=Math.min(34,laneWidth/(columns+1));
      positions.set(String(node.id),{x:x+(column-(columns-1)/2)*spacing,y:82+(row+.5)*270/rowCount});
    });
  });
  const edgeEnds=edge=>[String(typeof edge.source==='object'?edge.source.id:edge.source),String(typeof edge.target==='object'?edge.target.id:edge.target)];
  const visibleEdges=edges.filter(edge=>{const [from,to]=edgeEnds(edge);return positions.has(from)&&positions.has(to);}),edgeNodes=[];
  visibleEdges.forEach((edge,index)=>{
    const [from,to]=edgeEnds(edge),source=positions.get(from),target=positions.get(to),sameLane=Math.abs(source.x-target.x)<60;
    const distance=Math.abs(source.x-target.x),bend=sameLane?38+(index%3)*9:Math.max(30,distance*.37),direction=target.x>=source.x?1:-1;
    const pathData=sameLane?`M ${source.x} ${source.y} C ${source.x+bend} ${source.y-12}, ${target.x+bend} ${target.y+12}, ${target.x} ${target.y}`:`M ${source.x} ${source.y} C ${source.x+direction*bend} ${source.y}, ${target.x-direction*bend} ${target.y}, ${target.x} ${target.y}`;
    const baseOpacity=edge.type==='SIMILAR_TO'?.08:.22,path=svgElement('path',{d:pathData,fill:'none',stroke:'#8fa6c0','stroke-width':1.05,'stroke-opacity':baseOpacity,'marker-end':`url(#${marker.id})`,'pointer-events':'stroke'}),title=svgElement('title');title.textContent=[edge.type||'关联',from+' → '+to].join(' · ');path.append(title);svg.append(path);edgeNodes.push({path,from,to,baseOpacity});
  });
  const caption=el('div','graph-selection graph-selection-empty'),nodeElements=new Map();caption.append(el('span','',`当前子图：${nodes.length} 个节点 · ${visibleEdges.length} 条真实关系`),el('p','','选择节点，查看它的名称、原编号及当前子图中的关联。'));
  const selectNode=node=>{
    const id=String(node.id),neighbors=new Set([id]);let related=0;
    edgeNodes.forEach(({path,from,to})=>{const hit=from===id||to===id;if(hit){neighbors.add(from);neighbors.add(to);related++;}path.setAttribute('stroke-opacity',hit?.88:.045);path.setAttribute('stroke-width',hit?1.8:1);path.setAttribute('stroke',hit?(NODE_COLORS[node.type]||'#3b6fe8'):'#a8b8ca');});
    nodeElements.forEach((group,nodeId)=>{const selected=nodeId===id;group.classList.toggle('selected',selected);group.setAttribute('aria-pressed',selected?'true':'false');group.setAttribute('opacity',neighbors.has(nodeId)?1:.33);});
    caption.classList.remove('graph-selection-empty');caption.classList.add('graph-selected-detail');caption.replaceChildren(el('strong','',(NODE_TYPES[node.type]||node.type||'节点')+' · '+(node.label||node.id)),el('span','',`${id} · 当前子图 ${related} 条关联`));if(node.description)caption.append(el('p','',compactText(node.description,420)));
  };
  nodes.forEach(node=>{
    const id=String(node.id),pos=positions.get(id),focused=id===String(focusId),color=NODE_COLORS[node.type]||'#718299';
    const group=svgElement('g',{class:'graph-node',tabindex:0,role:'button','aria-pressed':'false','aria-label':(NODE_TYPES[node.type]||node.type||'节点')+'：'+(node.label||node.id)}),halo=svgElement('circle',{cx:pos.x,cy:pos.y,r:focused?17:12,fill:color,'fill-opacity':focused?.18:.08}),circle=svgElement('circle',{cx:pos.x,cy:pos.y,r:focused?10:7.5,fill:color,stroke:'#fff','stroke-width':2.5}),title=svgElement('title');
    title.textContent=[node.id,node.label,node.description].filter(Boolean).join(' · ');group.append(halo,circle,title);
    if(groups.get(node.type||'Entity').length<=4){const label=svgElement('text',{x:pos.x,y:pos.y+26,'text-anchor':'middle',fill:'#52657e','font-size':11,class:'graph-node-label'});label.textContent=compactText(node.label||node.id,11);group.append(label);}
    group.addEventListener('click',()=>selectNode(node));group.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();selectNode(node);}});svg.append(group);nodeElements.set(id,group);
  });
  host.append(svg,caption);if(focusId){const focused=nodes.find(node=>String(node.id)===String(focusId));if(focused)selectNode(focused);}
  return {nodes:nodes.length,edges:visibleEdges.length};
}
async function loadProjectGraph(){
  const host=$('project-graph');host.replaceChildren(el('div','loading-placeholder','正在读取图谱实际节点与关系…'));
  try{const data=await api('/api/project/graph?limit=40'),visible=renderGraph(host,data);const counts=state.project?.node_type_counts||{},legend=$('graph-legend');legend.replaceChildren(el('h3','','完整原图构成'));
    Object.entries(counts).forEach(([type,count])=>{const row=el('div','legend-row'),dot=el('span','legend-dot');dot.style.background=NODE_COLORS[type]||'#718299';row.append(dot,el('span','',NODE_TYPES[type]||type),el('strong','',numberText(count)));legend.append(row);});legend.append(el('p','graph-overview-meta',`当前展示 ${visible.nodes} 个节点、${visible.edges} 条关系，来自完整原图的 ${numberText(data.total_nodes)} 个节点和 ${numberText(data.total_edges)} 条关系。`));$('project-graph-note').textContent=data.note||'当前图形只展示原图的有界子集，连线均来自快照中的实际关系。';
  }catch(error){host.replaceChildren(el('div','inline-error',error.message));}
}
async function loadCardGraph(id,container,button){
  if(button)button.disabled=true;let panel=container.querySelector('.inline-card-graph');if(!panel){panel=el('div','inline-card-graph graph-canvas');container.append(panel);}panel.replaceChildren(el('div','loading-placeholder','正在查询该知识卡在原图中的关联…'));
  try{const data=await api('/api/project/cards/'+encodeURIComponent(id)+'/graph');renderGraph(panel,data,state.cards.get(id)?.original_id||state.cards.get(id)?.source_ref?.original_id||id);panel.append(el('p','graph-note',data.note||'当前原图关联查询，不代表历史决策生成时使用的路径。'));}catch(error){panel.replaceChildren(el('div','inline-error',error.message));}finally{if(button)button.disabled=false;}
}
async function loadRecords(){
  const version=++state.recordsVersion,list=$('record-list');list.replaceChildren(el('div','loading-placeholder','正在读取历史记录…'));$('record-prev').disabled=true;$('record-next').disabled=true;
  if(!state.project){try{state.project=await api('/api/project/summary');populateRecordFilters(state.project);}catch(_) {}}
  const query=new URLSearchParams({page:String(state.recordPage),page_size:'10'});if($('record-action').value)query.set('action',$('record-action').value);if($('record-location').value)query.set('location',$('record-location').value);
  try{const data=await api('/api/project/records?'+query.toString());if(version!==state.recordsVersion)return;const items=data.items||[];state.recordPage=data.page||1;state.recordPages=data.pages||1;$('record-total').textContent=numberText(data.total)+' 条';$('record-page').textContent=`${state.recordPage} / ${state.recordPages} 页`;$('record-prev').disabled=state.recordPage<=1;$('record-next').disabled=state.recordPage>=state.recordPages;list.replaceChildren();
    if(!items.length){list.append(el('div','loading-placeholder','没有符合筛选条件的历史记录。'));$('record-detail').replaceChildren(el('div','loading-placeholder','可调整动作或位置后重新筛选。'));return;}
    items.forEach(record=>{const button=el('button','record-list-item'+(state.selectedRecord===record.id?' selected':''));button.type='button';button.dataset.recordId=record.id;const head=el('div','record-list-top');head.append(el('span','record-id',record.id),el('span','record-action-tag '+(record.action||''),record.action_label||record.action||'未记录'));button.append(head,el('strong','',record.timestamp||'未记录时间'),locationNode('span','record-location',record.location),el('p','',compactText(record.reason,82)));button.addEventListener('click',()=>openRecord(record.id));list.append(button);});
    const selected=items.find(item=>item.id===state.selectedRecord)||items[0];await openRecord(selected.id);
  }catch(error){if(version!==state.recordsVersion)return;list.replaceChildren(el('div','inline-error',error.message));$('record-page').textContent='未能读取';}
}
async function openRecord(id){
  const version=++state.detailVersion;state.selectedRecord=id;$('record-list').querySelectorAll('[data-record-id]').forEach(button=>button.classList.toggle('selected',button.dataset.recordId===id));const panel=$('record-detail');panel.replaceChildren(el('div','loading-placeholder','正在展开历史方案…'));
  try{const record=await api('/api/project/records/'+encodeURIComponent(id));if(version!==state.detailVersion)return;renderRecordDetail(record);const graph=await api('/api/project/records/'+encodeURIComponent(id)+'/graph');if(version!==state.detailVersion)return;const host=$('record-original-graph');if(host){if(graph.found)renderGraph(host,graph);else host.replaceChildren();}}
  catch(error){if(version===state.detailVersion)panel.replaceChildren(el('div','inline-error',error.message));}
}
function valueLabel(value){if(value===true)return '通过';if(value===false)return '未通过';return value==null?'原记录未保存':typeof value==='object'?JSON.stringify(value):String(value);}
function renderRecordDetail(record){
  const panel=$('record-detail');panel.replaceChildren();const top=el('div','record-detail-heading');top.append(el('span','eyebrow','ARCHIVED DECISION · '+record.id),el('span','archive-label','原工程历史记录'));panel.append(top);
  const action=el('div','historical-action '+(record.action||'')),head=el('div');head.append(el('span','','已记录的动作'),el('h2','',record.action_label||record.action||'动作未记录'));const meta=el('div');meta.append(el('span','',record.timestamp||''),el('span','',record.duration_minutes!=null?`记录时长 ${record.duration_minutes} 分钟`:'时长未记录'));action.append(head,meta);panel.append(action,locationNode('p','record-full-location',record.location,'位置未记录'));
  const ask=el('button','secondary-button','问问这个方案');ask.prepend(icon('chat'));ask.addEventListener('click',()=>askAboutRecord(record));panel.append(ask,subtitle('历史聚合观测','chart'));
  const observation=record.observation||{},labels={ped_in:'行人进入',ped_out:'行人离开',ped_count:'行人总量',ped_total:'行人总量',pedestrian_count:'行人总量',veh_in:'车辆进入',veh_out:'车辆离开',veh_count:'车辆总量',vehicle_count:'车辆总量',overspeed_count:'超速事件代理',speeding:'超速事件代理',risk_score:'风险评分',risk_level:'风险等级',gate_status:'记录通行状态'};
  const metrics=el('div','record-metrics');Object.entries(observation).filter(([key,value])=>!['timestamp','gate_id','location','gate_name'].includes(key)&&value!=null&&typeof value!=='object').forEach(([key,value])=>{const metric=el('div','record-metric');metric.append(el('small','',labels[key]||key),el('strong','',typeof value==='number'?numberText(value):key==='gate_status'?({open:'开放',closed:'关闭',normal:'正常'}[String(value)]||String(value)):String(value)));metrics.append(metric);});panel.append(metrics.children.length?metrics:el('p','muted-copy','原文件没有保存可展示的聚合指标。'));
  panel.append(subtitle('原记录的决策理由','file'),el('div','record-reason',record.reason||'原记录未保存理由。'));
  const checks=el('div','record-check-grid');[['原基础校验',record.validation?.is_valid],['原首轮图校验',record.recorded_pre_validation?.graph_valid],['最终图校验',record.validation?.graph_valid]].forEach(([label,value])=>{const item=el('div','record-check'+(value===true?' passed':value===false?' not-passed':''));item.append(el('small','',label),el('span','',valueLabel(value)));checks.append(item);});panel.append(subtitle('原文件保存的校验字段','shield'),checks);
  const originalEvidence=Array.isArray(record.evidence)?record.evidence:[];panel.append(subtitle('历史检索证据','graph'));if(originalEvidence.length)renderKnowledgeLinks(panel,originalEvidence,'原记录保存的证据');
  else panel.append(el('p','missing-evidence','原文件未保存检索证据编号，不能还原当次生成使用的证据链。'));
  const originalGraph=el('div','record-original-graph');originalGraph.id='record-original-graph';panel.append(originalGraph);
  if((record.mentioned_evidence||[]).length){panel.append(subtitle('原理由提及的卡片','file-search'),el('p','small-evidence-note','以下编号出现在原理由文本中，不等于原文件保存的当次检索证据。'));renderKnowledgeLinks(panel,record.mentioned_evidence);}
  panel.append(subtitle('检索相关项目知识','library'),el('p','small-evidence-note','使用当前知识库查找与此记录相关的内容；它们是本次检索参考。'));
  const relatedButton=el('button','secondary-button','检索相关知识');relatedButton.prepend(icon('file-search'));const related=el('div','related-knowledge');related.id='record-related';relatedButton.addEventListener('click',()=>loadRelatedKnowledge(record.id,related,relatedButton));panel.append(relatedButton,related);
  const source=record.source_ref||{};panel.append(el('p','record-source-note',[source.file||'原工程历史结果文件',source.index!=null?'记录索引 '+source.index:'',source.sha256?'源文件校验已保存':''].filter(Boolean).join(' · ')));
}
function renderKnowledgeLinks(container,cards,label=''){
  if(label)container.append(el('p','small-evidence-note',label));const list=el('div','knowledge-links');cards.forEach(card=>{if(typeof card==='string'){const button=el('button','knowledge-link');button.append(el('strong','',card));button.addEventListener('click',()=>openCard(card));list.append(button);return;}state.cards.set(card.id,card);const button=el('button','knowledge-link'),head=el('div');head.append(el('span','source-tag',cardTag(card)),el('small','',card.original_id||card.source_ref?.original_id||card.id));button.append(head,el('strong','',card.title||card.id),el('p','',compactText(card.content,160)));button.addEventListener('click',()=>openCard(card));list.append(button);});container.append(list);
}
async function loadRelatedKnowledge(id,container,button){
  button.disabled=true;container.replaceChildren(el('div','loading-placeholder','正在检索当前项目知识库…'));
  try{const data=await api('/api/project/records/'+encodeURIComponent(id)+'/related');container.replaceChildren(el('p','small-evidence-note',data.note||'本次检索参考，不是历史记录原引用。'));if((data.cards||[]).length)renderKnowledgeLinks(container,data.cards);else container.append(el('p','muted-copy','没有检索到足够相关的知识卡片。'));}
  catch(error){container.replaceChildren(el('div','inline-error',error.message));}finally{button.disabled=false;}
}

hydrateIcons();
document.querySelectorAll('.nav-item').forEach(button=>button.addEventListener('click',()=>switchView(button.dataset.view)));
setScope('project');
document.querySelectorAll('[data-go]').forEach(button=>button.addEventListener('click',()=>switchView(button.dataset.go)));
$('answer-scope').addEventListener('change',event=>{if(state.busy){event.target.value=state.scope;toast('请等待当前回答完成后切换知识范围。');return;}clearChat();setScope(event.target.value);});
$('refresh-project').addEventListener('click',()=>{state.project=null;loadProject();});
$('record-filter-form').addEventListener('submit',event=>{event.preventDefault();state.recordPage=1;state.selectedRecord=null;loadRecords();});
$('record-reset').addEventListener('click',()=>{$('record-action').value='';$('record-location').value='';state.recordPage=1;state.selectedRecord=null;loadRecords();});
$('record-prev').addEventListener('click',()=>{if(state.recordPage>1){state.recordPage--;state.selectedRecord=null;loadRecords();}});
$('record-next').addEventListener('click',()=>{if(state.recordPage<state.recordPages){state.recordPage++;state.selectedRecord=null;loadRecords();}});
$('chat-form').addEventListener('submit',event=>{event.preventDefault();sendQuestion($('question').value);});
$('question').addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){event.preventDefault();if(!state.busy)sendQuestion(event.currentTarget.value);}});
$('question').addEventListener('input',event=>{event.currentTarget.style.height='auto';event.currentTarget.style.height=Math.min(event.currentTarget.scrollHeight,170)+'px';});
$('new-chat').addEventListener('click',clearChat);$('refresh-status').addEventListener('click',()=>{loadStatus();toast('正在刷新运行状态。');});$('refresh-documents').addEventListener('click',()=>Promise.all([loadDocuments(),loadStatus()]));$('refresh-audit').addEventListener('click',loadAudit);
$('decision-form').addEventListener('submit',runDecision);
$('document-upload').addEventListener('change',event=>uploadDocument(event.target.files[0]));
const uploadZone=$('upload-zone');uploadZone.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();$('document-upload').click();}});
['dragenter','dragover'].forEach(name=>uploadZone.addEventListener(name,event=>{event.preventDefault();uploadZone.classList.add('dragging');}));['dragleave','drop'].forEach(name=>uploadZone.addEventListener(name,event=>{event.preventDefault();uploadZone.classList.remove('dragging');}));uploadZone.addEventListener('drop',event=>{if(event.dataTransfer.files.length>1){toast('请一次导入一份文档。');return;}uploadDocument(event.dataTransfer.files[0]);});
$('fullscreen-button').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch(_){toast('当前窗口不支持网页全屏，可使用浏览器的全屏功能。');}});
$('close-modal').addEventListener('click',closeModal);$('card-modal').addEventListener('click',event=>{if(event.target===$('card-modal'))closeModal();});
document.addEventListener('keydown',event=>{if($('card-modal').hidden)return;if(event.key==='Escape'){closeModal();return;}if(event.key==='Tab'){const nodes=Array.from($('card-modal').querySelectorAll('button,a[href],[tabindex="0"]')).filter(node=>!node.disabled&&node.getClientRects().length);const first=nodes[0],last=nodes[nodes.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}});
window.addEventListener('hashchange',()=>switchView(location.hash.slice(1)));
loadStatus();switchView(location.hash.slice(1)||'project');
