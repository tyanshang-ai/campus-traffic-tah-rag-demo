#!/bin/zsh
cd -- "${0:A:h}"
if [[ -x .venv/bin/python ]]; then
  .venv/bin/python launch.py
else
  python3 launch.py
fi
if [[ $? -ne 0 ]]; then
  echo '启动失败，请查看上方提示。按回车关闭。'
  read
fi
