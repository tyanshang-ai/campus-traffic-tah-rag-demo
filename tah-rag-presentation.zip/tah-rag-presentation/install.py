"""Create this checkout's virtual environment and install its declared dependencies.

No API calls are made and existing .env files are never opened or overwritten.
"""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def environment_python(directory: Path, platform_name: str = os.name) -> Path:
    return directory / ("Scripts/python.exe" if platform_name == "nt" else "bin/python")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Install the local presentation system")
    parser.add_argument("--check", action="store_true", help="Check Python and package-file availability without installing")
    args = parser.parse_args(argv)
    if sys.version_info < (3, 10):
        print("需要 Python 3.10 或更新版本，建议安装 Python 3.11 或 3.12。")
        return 1
    requirements = ROOT / "requirements.txt"
    if not requirements.is_file():
        print("缺少 requirements.txt，请完整解压 GitHub 下载的项目压缩包。")
        return 1
    print("Python：", sys.version.split()[0])
    print("项目目录：", ROOT)
    if args.check:
        print("安装前检查通过；未安装依赖、未读取或更改密钥配置。")
        return 0
    virtualenv = ROOT / ".venv"
    python = environment_python(virtualenv)
    try:
        if not python.is_file():
            if virtualenv.exists():
                print(".venv 已存在，但不适用于当前电脑。请先将其改名为 .venv_old，再重新安装。")
                return 1
            print("正在创建项目独立环境 .venv …")
            subprocess.run([sys.executable, "-m", "venv", str(virtualenv)], check=True, cwd=ROOT)
        print("正在安装依赖，首次安装需要联网 …")
        subprocess.run([str(python), "-m", "pip", "install", "--disable-pip-version-check", "-r", str(requirements)], check=True, cwd=ROOT)
        example = ROOT / ".env.example"
        destination = ROOT / ".env"
        if not destination.exists() and example.is_file():
            shutil.copyfile(example, destination)
            destination.chmod(0o600)
            print("已从示例创建本机 .env，请自行填写私下获取的 GLM 密钥。")
        else:
            print("已有密钥配置保持原样；本安装器不读取 .env 内容。")
    except subprocess.CalledProcessError:
        print("安装未完成。请检查上方错误、网络连接和 Python 的 venv/pip 支持，然后重新运行安装脚本。")
        return 1
    except OSError as exc:
        print("无法完成安装：", exc)
        return 1
    print("安装完成。填写本机 .env 的 TAH_GLM_API_KEY 后，双击对应系统的启动演示脚本。")
    print("未配置密钥时，也可使用资料摘录与已有方案展示。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
