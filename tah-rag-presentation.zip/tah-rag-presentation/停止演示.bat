@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo 未找到本机安装环境。若系统正在运行，可在启动窗口按 Ctrl+C 停止。
    pause
    exit /b 1
)
".venv\Scripts\python.exe" stop.py
set "TAH_STOP_EXIT=%ERRORLEVEL%"
pause
exit /b %TAH_STOP_EXIT%
