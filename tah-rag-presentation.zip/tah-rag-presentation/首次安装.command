#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1

tah_python=""
for tah_candidate in python3 python3.14 python3.13 python3.12 python3.11 python3.10; do
  if command -v "$tah_candidate" >/dev/null 2>&1 && "$tah_candidate" -c 'import sys; sys.exit(sys.version_info < (3, 10))' >/dev/null 2>&1; then
    tah_python="$tah_candidate"
    break
  fi
done

if [ -z "$tah_python" ]; then
  echo '未找到 Python 3.10+。请先安装 Python 3.11 或 3.12，再重新双击本文件。'
  read -r -p '按回车关闭。' tah_reply
  exit 1
fi

"$tah_python" install.py
tah_result=$?
if [ "$tah_result" -ne 0 ]; then
  echo '安装失败，请保留上方错误信息。'
fi
read -r -p '按回车关闭。' tah_reply
exit "$tah_result"
