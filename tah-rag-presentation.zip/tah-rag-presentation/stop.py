"""Stop only the verified server instance created by this project's launcher."""
from pathlib import Path
import json
import os
import signal
import urllib.request

state = Path(__file__).resolve().parent / "data/runtime/server.json"
if not state.exists():
    print("本项目没有正在运行的服务。")
else:
    saved = json.loads(state.read_text())
    try:
        with urllib.request.urlopen(saved["url"] + "/api/status", timeout=3) as response:
            current = json.load(response)
        if (current.get("app_id") == "tah-rag-original-project" and current.get("instance_id") == saved["instance_id"]
                and current.get("process_pid") == saved["pid"]):
            os.kill(saved["pid"], signal.SIGTERM)
            print("已停止校园交通治理演示服务。")
        else:
            print("端口对应其他服务，未执行停止操作。")
    except (OSError, ValueError):
        print("原演示服务已结束，未停止其他进程。")
