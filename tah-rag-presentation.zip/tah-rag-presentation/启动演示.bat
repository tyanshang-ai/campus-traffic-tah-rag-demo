@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo 请先双击“首次安装.bat”，完成依赖安装后再启动。
    pause
    exit /b 1
)
".venv\Scripts\python.exe" launch.py
set "TAH_LAUNCH_EXIT=%ERRORLEVEL%"
if not "%TAH_LAUNCH_EXIT%"=="0" (
    echo 启动失败，请查看上方提示。
    pause
)
exit /b %TAH_LAUNCH_EXIT%
